# IQ test boti

Telegram bot: 30 savollik IQ test (o'zbekcha va ruscha), pullik natija, admin tasdig'i, sertifikat tarqatish va ustozlar uchun alohida bo'lim.

## Ishga tushirish

1. Telegramda **@BotFather** orqali bot yarating va tokenni oling.
2. Kutubxonani o'rnating: `pip install -r requirements.txt`
3. Tokenni bering va ishga tushiring:
   - Linux/Mac: `BOT_TOKEN="123:ABC..." python main.py`
   - Windows: `set BOT_TOKEN=123:ABC...` keyin `python main.py`
4. Botga kirib `/start` bosing. Admin paneli: `/admin` (ID `6818724924` asosiy admin).

Qo'shimcha muhit o'zgaruvchilari: `ADMIN_IDS` (vergul bilan bir nechta admin ID), `DB_PATH` (baza fayli, standart `data/iq_bot.sqlite3`).

## Narxlar, vaqt va kartalar

Hammasi `config.py` da: `PRICE_USER` (15 000), `PRICE_TEACHER` (50 000), `TEACHER_MAX_STUDENTS` (10), `TEST_MINUTES` (40), `CARDS` va `CARD_OWNER`.

## Qanday ishlaydi

**Oddiy foydalanuvchi.** Til tanlaydi, majburiy kanallarga obuna bo'ladi, familiya, ism, otasining ismi va yoshini yozadi, 30 savolni yechadi. Test tugagach karta rekvizitlari chiqadi, chek rasmini yuboradi. Kutish vaqtida maqtov va 2 ta mini-vazifa oladi. Admin tasdiqlagach IQ ball va toifalar bo'yicha tahlil ko'rsatiladi. Keyin «Sertifikat olish» tugmasi chiqadi (bepul).

**Admin.** Har bir chek rasm bilan adminlarga keladi: «Tasdiqlash» yoki «Rad etish». Sertifikat so'rovi kelganda «Sertifikat yuborish» ni bosib rasmni yuboradi, bot uni foydalanuvchiga o'zi jo'natadi. So'rovlar raqamlangani uchun ko'p mijoz bo'lsa ham chalkashmaydi. Foydalanuvchi ID bo'yicha qo'lda yuborish ham bor.

**Admin paneli (`/admin`).** Statistika (foizlarda), kutilayotgan to'lovlar, sertifikat tarqatish, majburiy obuna kanallarini qo'shish/o'chirish, adminlar, hammaga xabar yuborish, baza nusxasi.

**Ustozlar.** Ustoz ism va guruh nomini yozadi, 50 000 so'm to'laydi, admin tasdiqlagach havola oladi. 10 tagacha o'quvchi bepul topshiradi. Har bir o'quvchi tugatganda ustozga xabar keladi, panelda hamma ism va ball ko'rinadi. «Natijalarni olish» tugmasi hamma yechayotgan o'quvchini to'xtatadi va havolani yopadi. 11-o'quvchiga «joy to'lgan, mustaqil bajaring» deyiladi. Eng yuqori ball olgan o'quvchi nomiga sertifikat so'rash mumkin. O'quvchining o'ziga ball ko'rsatilmaydi, faqat ustozga yuboriladi.

## Muhim eslatmalar

- **Majburiy obuna:** botni kanalga **admin** qilib qo'shing, aks holda obuna tekshirilmaydi va bot foydalanuvchini to'smaydi.
- **Hosting:** bot doimiy ishlab turishi va **bazani saqlaydigan doimiy disk** bo'lishi kerak (SQLite fayl). Vaqtinchalik diskli hostingda (qayta ishga tushganda fayllar o'chadigan) to'lovlar va natijalar yo'qoladi. Har 12 soatda baza nusxasi adminlarga yuboriladi, lekin asosiy yechim doimiy disk. Har qanday hostingning joriy shartlarini o'zingiz tekshiring.
- **To'lov cheki:** bot bir xil rasmni ikki marta ishlatishni to'xtatadi, lekin boshqa skrinshotdagi soxta chekni aniqlay olmaydi. Admin summani o'z kartasida tekshirib tasdiqlashi kerak.
- **IQ natijasi** taxminiy va o'yin-kulgi/yo'nalish uchun. Natija matnida shu yozilgan. «Rasmiy IQ» deb sotmang.
- Bot ism va yoshni saqlaydi (ba'zan bolalarniki). Maxfiylikka e'tibor bering, baza faylini boshqalarga bermang.
- Test **real Telegram'da sinab ko'rilmagan**: mantiq soxta Telegram qatlami bilan 40 ta tekshiruvdan o'tgan. Ishga tushirgach 2 ta hisobdan (foydalanuvchi + admin) bir marta to'liq aylanib chiqing.

## Fayllar

`main.py` ishga tushirish · `config.py` sozlamalar · `questions.py`, `questions_ru.py` savollar · `scoring.py` hisoblash · `texts.py` matnlar · `db.py` baza · `core.py` test mexanizmi · `h_user.py`, `h_teacher.py`, `h_admin.py` handlerlar · `util.py` yordamchilar
