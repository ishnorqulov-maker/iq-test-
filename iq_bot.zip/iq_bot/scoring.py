"""Savollarni aralashtirish va natijani hisoblash (Telegramga bog'liq emas)."""
import json
import random

from questions import CATEGORY_NAMES, QUESTIONS
from questions_ru import QUESTIONS_RU

TOTAL_WEIGHT = sum(q["w"] for q in QUESTIONS)
CHANCE = 0.25  # 4 variantda tasodifiy topish ehtimoli


def question_order(seed: int):
    """Shu urinish uchun savollar tartibi (seed bo'yicha doim bir xil)."""
    order = list(range(len(QUESTIONS)))
    random.Random(seed).shuffle(order)
    return order


def option_order(seed: int, q_index: int):
    """Shu savol uchun variantlar tartibi: ko'rsatilgan joy -> asl indeks."""
    order = list(range(len(QUESTIONS[q_index]["o"])))
    random.Random(seed * 1000 + q_index).shuffle(order)
    return order


def build_view(seed: int, pos: int, lang: str = "uz"):
    """pos-o'rindagi savolni ko'rsatish uchun ma'lumot:
    (asl savol indeksi, matn, ko'rsatiladigan variantlar, ko'rsatilgan joy -> asl indeks)."""
    q_index = question_order(seed)[pos]
    q = QUESTIONS_RU[q_index] if lang == "ru" else QUESTIONS[q_index]
    opts = option_order(seed, q_index)
    return q_index, q["q"], [q["o"][i] for i in opts], opts


def explanation(q_index: int, lang: str = "uz") -> str:
    return (QUESTIONS_RU[q_index] if lang == "ru" else QUESTIONS[q_index])["e"]


def is_correct(q_index: int, chosen_original: int) -> bool:
    return QUESTIONS[q_index]["a"] == chosen_original


def age_bonus(age: int) -> float:
    """Yosh kichik bo'lsa, qiyin savollarda kamroq tajriba bor: kichik tuzatish."""
    if age <= 11:
        return 0.08
    if age <= 15:
        return 0.04
    return 0.0


def compute(answers_json: str, age: int):
    """(weighted_pct, iq, toifalar bo'yicha foiz) qaytaradi.
    Javob berilmagan savollar noto'g'ri hisoblanadi."""
    answers = json.loads(answers_json or "{}")
    got = 0
    cat_ok, cat_all = {}, {}
    for i, q in enumerate(QUESTIONS):
        cat_all[q["c"]] = cat_all.get(q["c"], 0) + q["w"]
        chosen = answers.get(str(i))
        if chosen is not None and is_correct(i, chosen):
            got += q["w"]
            cat_ok[q["c"]] = cat_ok.get(q["c"], 0) + q["w"]
    f = got / TOTAL_WEIGHT
    adj = min(1.0, f + age_bonus(age) * f)  # bonus faqat natijaga mutanosib: 0 ball 0 bo'lib qoladi
    norm = max(0.0, (adj - CHANCE) / (1 - CHANCE))
    iq = round(75 + 70 * norm)
    cats = {c: round(100 * cat_ok.get(c, 0) / cat_all[c]) for c in cat_all}
    return round(100 * f, 1), iq, cats


def level_title(iq: int) -> str:
    if iq >= 130:
        return "Juda yuqori"
    if iq >= 115:
        return "Yuqori"
    if iq >= 100:
        return "O'rtachadan yuqori"
    if iq >= 90:
        return "O'rtacha"
    if iq >= 80:
        return "O'rtachadan past"
    return "Past"


def strengths(cats: dict):
    """Eng kuchli va eng zaif toifaning kalitlari (nomi til bo'yicha texts.py dan olinadi)."""
    ranked = sorted(cats.items(), key=lambda kv: kv[1], reverse=True)
    return ranked[0][0], ranked[-1][0]
