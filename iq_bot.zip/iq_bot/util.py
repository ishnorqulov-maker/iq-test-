"""Umumiy yordamchi funksiyalar: tugmalar, xavfsiz yuborish, obuna tekshiruvi, adminlarga xabar."""
import html
import logging
from datetime import datetime

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import TelegramError

import config
import db
from texts import tr

log = logging.getLogger("iq_bot")


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""))


def lang_of(user_id: int) -> str:
    return db.get_lang(user_id) or "uz"


def fmt_dt(ts) -> str:
    return datetime.fromtimestamp(ts or 0, config.TZ).strftime("%d.%m.%Y %H:%M")


def kb(rows) -> InlineKeyboardMarkup:
    """rows: [[(matn, callback_data yoki 'url:https://...'), ...], ...]"""
    out = []
    for row in rows:
        line = []
        for text, data in row:
            if data.startswith("url:"):
                line.append(InlineKeyboardButton(text, url=data[4:]))
            else:
                line.append(InlineKeyboardButton(text, callback_data=data))
        out.append(line)
    return InlineKeyboardMarkup(out)


def menu_kb(lang: str) -> InlineKeyboardMarkup:
    return kb([
        [(tr(lang, "btn_test"), "test:start")],
        [(tr(lang, "btn_results"), "res:list")],
        [(tr(lang, "btn_teacher"), "tm")],
        [(tr(lang, "btn_help"), "help"), (tr(lang, "btn_lang"), "chlang")],
    ])


def back_menu_kb(lang: str) -> InlineKeyboardMarkup:
    return kb([[(tr(lang, "btn_menu"), "menu")]])


async def safe_send(bot, chat_id, text, **kw):
    """Xabar yuboradi. Foydalanuvchi botni bloklagan bo'lsa ham dastur to'xtamaydi."""
    try:
        return await bot.send_message(chat_id, text, parse_mode="HTML", **kw)
    except TelegramError as e:
        log.warning("send_message %s xato: %s", chat_id, e)
        return None


async def edit_or_send(update, context, text, markup=None):
    """Tugma bosilgan bo'lsa shu xabarni tahrirlaydi, bo'lmasa yangi xabar yuboradi."""
    q = update.callback_query
    if q is not None and q.message is not None:
        try:
            await q.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
            return
        except TelegramError:
            pass  # masalan, xabar rasm yoki o'zgarmagan: yangisini yuboramiz
    await safe_send(context.bot, update.effective_chat.id, text, reply_markup=markup)


async def missing_channels(bot, user_id: int):
    """Foydalanuvchi obuna bo'lmagan majburiy kanallar ro'yxati."""
    if db.is_admin(user_id):
        return []
    missing = []
    for ch in db.channels():
        try:
            m = await bot.get_chat_member(ch["chat_id"], user_id)
        except TelegramError as e:
            # Bot kanalda admin emas yoki kanal topilmadi: foydalanuvchini bloklamaymiz
            log.warning("Kanal %s tekshirib bo'lmadi: %s", ch["chat_id"], e)
            continue
        left = m.status in ("left", "kicked") or (
            m.status == "restricted" and not getattr(m, "is_member", True)
        )
        if left:
            missing.append(ch)
    return missing


async def notify_admins(bot, text, reply_markup=None, photo=None):
    for aid in db.admin_ids():
        try:
            if photo:
                await bot.send_photo(aid, photo, caption=text, parse_mode="HTML",
                                     reply_markup=reply_markup)
            else:
                await bot.send_message(aid, text, parse_mode="HTML", reply_markup=reply_markup)
        except TelegramError as e:
            log.warning("Adminga (%s) yuborib bo'lmadi: %s", aid, e)


def parse_name(text: str, min_words: int = 3):
    """Familiya, ism, otasining ismi. Faqat harflar; juda uzun yoki qisqa matn rad etiladi."""
    parts = (text or "").strip().split()
    if not (min_words <= len(parts) <= 6) or len(text) > 100:
        return None
    for p in parts:
        if not any(ch.isalpha() for ch in p) or not all(ch.isalpha() or ch in "'’`ʻʼ-." for ch in p):
            return None
    return " ".join(p[:1].upper() + p[1:] for p in parts)


def bar(pct: int) -> str:
    filled = round(pct / 20)
    return "▰" * filled + "▱" * (5 - filled)
