"""Ustozlar va o'quv markazlari bo'limi."""
import config
import core
import db
from texts import money, tr
from util import (back_menu_kb, edit_or_send, esc, kb, lang_of, menu_kb, notify_admins,
                  parse_name, safe_send)

TOTAL = core.TOTAL


# ---------------------------------------------------------------- o'quvchi havola orqali kiradi
async def student_entry(update, context, code: str):
    uid = update.effective_user.id
    lang = lang_of(uid)
    bot = context.bot
    t = db.teacher_by_code(code)
    if not t or t["status"] == "awaiting_payment":
        await safe_send(bot, uid, tr(lang, "student_invalid"), reply_markup=menu_kb(lang))
        return
    if t["status"] == "closed":
        await safe_send(bot, uid, tr(lang, "student_closed"), reply_markup=menu_kb(lang))
        return
    prev = db.student_in_teacher(t["id"], uid)
    if prev:
        if prev["status"] == "in_progress" and prev["deadline"] >= db.now():
            await core.send_question(bot, prev)
        else:
            await safe_send(bot, uid, tr(lang, "student_already"), reply_markup=menu_kb(lang))
        return
    if db.slots_taken(t["id"]) >= t["max_students"]:
        await safe_send(bot, uid, tr(lang, "student_full"), reply_markup=menu_kb(lang))
        return
    context.user_data["reg"] = {"kind": "student", "teacher_id": t["id"]}
    context.user_data["state"] = "name"
    await safe_send(
        bot, uid,
        tr(lang, "student_invite", teacher=esc(t["full_name"]), org=esc(t["org"])) + "\n\n" + tr(lang, "ask_name"),
    )


# ---------------------------------------------------------------- ustoz menyusi
async def cb_teacher_menu(update, context):
    await update.callback_query.answer()
    uid = update.effective_user.id
    lang = lang_of(uid)
    context.user_data.pop("state", None)
    rows = [[(tr(lang, "btn_teacher_new"), "tn")]]
    if db.teachers_of(uid):
        rows.append([(tr(lang, "btn_teacher_mine"), "tl")])
    rows.append([(tr(lang, "btn_menu"), "menu")])
    await edit_or_send(
        update, context,
        tr(lang, "teacher_intro", price=money(config.PRICE_TEACHER)), kb(rows),
    )


async def cb_teacher_new(update, context):
    await update.callback_query.answer()
    uid = update.effective_user.id
    context.user_data["state"] = "t_name"
    context.user_data["treg"] = {}
    await safe_send(context.bot, uid, tr(lang_of(uid), "teacher_ask_name"))


async def on_teacher_name(update, context):
    uid = update.effective_user.id
    lang = lang_of(uid)
    name = parse_name(update.message.text, min_words=2)
    if not name:
        await safe_send(context.bot, uid, tr(lang, "name_bad").replace("3", "2"))
        return
    context.user_data["treg"]["name"] = name
    context.user_data["state"] = "t_org"
    await safe_send(context.bot, uid, tr(lang, "teacher_ask_org"))


async def on_teacher_org(update, context):
    uid = update.effective_user.id
    lang = lang_of(uid)
    org = (update.message.text or "").strip()
    treg = context.user_data.get("treg") or {}
    if not (2 <= len(org) <= 100) or "name" not in treg:
        await safe_send(context.bot, uid, tr(lang, "text_bad"))
        return
    tid = db.create_teacher(uid, treg["name"], org)
    context.user_data.pop("treg", None)
    context.user_data["receipt"] = {"kind": "teacher", "ref": tid}
    context.user_data["state"] = "receipt"
    await safe_send(
        context.bot, uid,
        core.pay_prompt_text(lang, config.PRICE_TEACHER, key="teacher_pay_prompt"),
    )


async def cb_teacher_list(update, context):
    await update.callback_query.answer()
    uid = update.effective_user.id
    lang = lang_of(uid)
    rows = []
    names = tr(lang, "teacher_status")
    for t in db.teachers_of(uid)[:15]:
        mark = {"active": "🟢", "closed": "🔒"}.get(t["status"], "⏳")
        label = f"{mark} {t['org']} · {names[t['status']]}"
        rows.append([(label, f"tp:{t['id']}" if t["status"] != "awaiting_payment" else f"trc:{t['id']}")])
    rows.append([(tr(lang, "btn_back"), "tm")])
    await edit_or_send(update, context, tr(lang, "btn_teacher_mine"), kb(rows))


async def cb_teacher_receipt(update, context):
    """To'lovi tasdiqlanmagan havola uchun chekni qayta yuborish."""
    q = update.callback_query
    await q.answer()
    lang = lang_of(q.from_user.id)
    t = db.get_teacher(int(q.data.split(":")[1]))
    if not t or t["user_id"] != q.from_user.id or t["status"] != "awaiting_payment":
        return
    context.user_data["receipt"] = {"kind": "teacher", "ref": t["id"]}
    context.user_data["state"] = "receipt"
    await safe_send(context.bot, q.from_user.id,
                    core.pay_prompt_text(lang, config.PRICE_TEACHER, key="teacher_pay_prompt"))


# ---------------------------------------------------------------- ustoz paneli
def panel_text(t, lang: str, bot_username: str) -> str:
    studs = db.teacher_students(t["id"])
    done = sorted([s for s in studs if s["status"] in ("finished", "expired")],
                  key=lambda s: (-(s["score_pct"] or 0), s["finished_at"] or 0))
    waiting = [s for s in studs if s["status"] == "in_progress"]
    stopped = [s for s in studs if s["status"] == "stopped"]
    rows, i = [], 0
    for s in done:
        i += 1
        rows.append(tr(lang, "teacher_row_done", i=i, name=esc(s["full_name"]), iq=s["iq"],
                       correct=s["correct"], total=TOTAL))
    for s in waiting:
        i += 1
        rows.append(tr(lang, "teacher_row_wait", i=i, name=esc(s["full_name"])))
    for s in stopped:
        i += 1
        rows.append(tr(lang, "teacher_row_stopped", i=i, name=esc(s["full_name"]),
                       answered=s["answered"], total=TOTAL))
    return tr(
        lang, "teacher_panel",
        org=esc(t["org"]), status=tr(lang, "teacher_status")[t["status"]],
        taken=len(studs), max_students=t["max_students"], done=len(done),
        link=f"https://t.me/{bot_username}?start=t_{t['code']}",
        rows="\n".join(rows) if rows else tr(lang, "teacher_no_students"),
    )


def panel_kb(t, lang: str):
    rows = [[(tr(lang, "btn_refresh"), f"tp:{t['id']}")]]
    if t["status"] == "active":
        rows.append([(tr(lang, "btn_get_results"), f"ts:{t['id']}")])
    rows.append([(tr(lang, "btn_teacher_cert"), f"tc:{t['id']}")])
    rows.append([(tr(lang, "btn_back"), "tl")])
    return kb(rows)


def own_teacher(q):
    t = db.get_teacher(int(q.data.split(":")[1]))
    if not t or t["user_id"] != q.from_user.id or t["status"] == "awaiting_payment":
        return None
    return t


async def cb_teacher_panel(update, context):
    q = update.callback_query
    t = own_teacher(q)
    await q.answer()
    if not t:
        return
    lang = lang_of(q.from_user.id)
    await edit_or_send(update, context, panel_text(t, lang, context.bot.username), panel_kb(t, lang))


async def cb_stop_confirm(update, context):
    q = update.callback_query
    t = own_teacher(q)
    await q.answer()
    if not t or t["status"] != "active":
        return
    lang = lang_of(q.from_user.id)
    await edit_or_send(
        update, context, tr(lang, "teacher_stop_confirm"),
        kb([[(tr(lang, "btn_yes"), f"tsy:{t['id']}"), (tr(lang, "btn_no"), f"tp:{t['id']}")]]),
    )


async def cb_stop_do(update, context):
    """Hozir test yechayotgan hamma o'quvchini to'xtatadi, havolani yopadi, natijalarni ko'rsatadi."""
    q = update.callback_query
    t = own_teacher(q)
    await q.answer()
    if not t or t["status"] != "active":
        return
    lang = lang_of(q.from_user.id)
    db.close_teacher(t["id"])  # avval yopamiz: yangi o'quvchi qo'shila olmaydi
    for s in db.teacher_students(t["id"]):
        if s["status"] == "in_progress":
            await core.finalize(context.bot, s["id"], "stopped")
            await safe_send(context.bot, s["user_id"], tr(lang_of(s["user_id"]), "student_stopped"),
                            reply_markup=menu_kb(lang_of(s["user_id"])))
    t = db.get_teacher(t["id"])
    await edit_or_send(update, context, tr(lang, "teacher_stopped") + "\n\n" + panel_text(t, lang, context.bot.username),
                       panel_kb(t, lang))


async def cb_teacher_cert(update, context):
    """Eng yuqori ball olgan o'quvchi nomiga sertifikat so'rovi (bepul)."""
    q = update.callback_query
    t = own_teacher(q)
    if not t:
        await q.answer()
        return
    lang = lang_of(q.from_user.id)
    done = [s for s in db.teacher_students(t["id"]) if s["status"] in ("finished", "expired")]
    if not done:
        await q.answer(tr(lang, "teacher_cert_none"), show_alert=True)
        return
    await q.answer()
    top = max(done, key=lambda s: (s["score_pct"] or 0, -(s["finished_at"] or 0)))
    cid = db.create_cert(t["user_id"], top["id"], t["id"], top["full_name"])
    if cid is None:
        await safe_send(context.bot, q.from_user.id, tr(lang, "cert_exists"))
        return
    await safe_send(context.bot, q.from_user.id,
                    tr(lang, "teacher_cert_requested", name=esc(top["full_name"]), iq=top["iq"]))
    await notify_admins(
        context.bot,
        f"🎓 <b>Sertifikat so'rovi #{cid} (ustoz guruhi)</b>\n"
        f"Eng yuqori ball: <b>{esc(top['full_name'])}</b>, IQ {top['iq']} ({top['correct']}/{TOTAL})\n"
        f"Guruh: {esc(t['org'])}\nUstoz: {esc(t['full_name'])}\n"
        f"Sertifikat yuboriladigan ustoz ID: <code>{t['user_id']}</code>",
        reply_markup=kb([[("📤 Sertifikat yuborish", f"a:certsend:{cid}")]]),
    )
