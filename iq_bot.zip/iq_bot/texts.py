"""Foydalanuvchi va ustozlar uchun matnlar (uz / ru). HTML belgilash ishlatiladi."""
import config


def money(n: int) -> str:
    return f"{n:,}".replace(",", " ")


# Kalit: (o'zbekcha, ruscha). {nom} joylari tr() orqali to'ldiriladi.
T = {
    "choose_lang": ("🌐 Tilni tanlang / Выберите язык", "🌐 Tilni tanlang / Выберите язык"),
    "sub_required": (
        "📢 Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling, so'ng «✅ Obuna bo'ldim» tugmasini bosing:",
        "📢 Чтобы пользоваться ботом, подпишитесь на каналы ниже и нажмите «✅ Я подписался»:",
    ),
    "sub_missing": (
        "Hali hamma kanallarga obuna bo'lmagansiz. Iltimos, obuna bo'lib, qayta urinib ko'ring.",
        "Вы ещё подписались не на все каналы. Подпишитесь и попробуйте снова.",
    ),
    "btn_sub_done": ("✅ Obuna bo'ldim", "✅ Я подписался"),
    "btn_channel": ("📢 {title}", "📢 {title}"),
    "menu_title": (
        "🧠 <b>IQ test boti</b>\n\nQuyidagilardan birini tanlang:",
        "🧠 <b>Бот IQ-теста</b>\n\nВыберите нужное:",
    ),
    "btn_test": ("🧠 IQ testni boshlash", "🧠 Начать IQ-тест"),
    "btn_results": ("📊 Mening natijalarim", "📊 Мои результаты"),
    "btn_teacher": ("🏫 Ustozlar va o'quv markazlar", "🏫 Для учителей и учебных центров"),
    "btn_help": ("ℹ️ Yordam", "ℹ️ Помощь"),
    "btn_lang": ("🌐 Til / Язык", "🌐 Til / Язык"),
    "btn_back": ("⬅️ Orqaga", "⬅️ Назад"),
    "btn_menu": ("🏠 Bosh menyu", "🏠 Главное меню"),
    "help": (
        "ℹ️ <b>Yordam</b>\n\n"
        "• Test <b>30 ta savoldan</b> iborat, {minutes} daqiqa beriladi.\n"
        "• Test bepul topshiriladi, natijani ko'rish uchun <b>{price} so'm</b> to'lanadi.\n"
        "• To'lovni admin tasdiqlagach IQ ballingiz ko'rsatiladi.\n"
        "• Natijadan keyin <b>sertifikat bepul</b> so'rash mumkin.\n"
        "• Ustozlar va o'quv markazlari uchun alohida bo'lim bor.\n\n"
        "⚠️ Bu test taxminiy natija beradi va rasmiy psixologik tekshiruv o'rnini bosmaydi.",
        "ℹ️ <b>Помощь</b>\n\n"
        "• Тест состоит из <b>30 вопросов</b>, на него даётся {minutes} минут.\n"
        "• Пройти тест можно бесплатно, чтобы увидеть результат, нужно оплатить <b>{price} сум</b>.\n"
        "• После подтверждения оплаты админом вы увидите свой IQ.\n"
        "• После результата можно <b>бесплатно</b> запросить сертификат.\n"
        "• Для учителей и учебных центров есть отдельный раздел.\n\n"
        "⚠️ Этот тест даёт приблизительный результат и не заменяет официальное психологическое обследование.",
    ),
    "test_intro": (
        "🧠 <b>IQ test</b>\n\n"
        "• 30 ta savol (raqamlar, mantiq, so'zlar, fazoviy fikrlash)\n"
        "• Vaqt: <b>{minutes} daqiqa</b>\n"
        "• Natijani ko'rish: <b>{price} so'm</b> (test tugagach to'laysiz)\n\n"
        "Boshlashdan oldin ma'lumotlaringizni kiriting.",
        "🧠 <b>IQ-тест</b>\n\n"
        "• 30 вопросов (числа, логика, слова, пространственное мышление)\n"
        "• Время: <b>{minutes} минут</b>\n"
        "• Просмотр результата: <b>{price} сум</b> (оплата после теста)\n\n"
        "Перед началом введите свои данные.",
    ),
    "ask_name": (
        "✍️ <b>Familiya, ism va otangizning ismini</b> to'liq yozing.\n"
        "Masalan: <i>Karimov Aziz Bahodirovich</i>",
        "✍️ Напишите полностью <b>фамилию, имя и отчество</b>.\n"
        "Например: <i>Каримов Азиз Баходирович</i>",
    ),
    "name_bad": (
        "❌ Iltimos, familiya, ism va otangizning ismini to'liq yozing (kamida 3 ta so'z, faqat harflar).",
        "❌ Пожалуйста, напишите полностью фамилию, имя и отчество (минимум 3 слова, только буквы).",
    ),
    "ask_age": ("🎂 Yoshingiz nechada? (faqat raqam)", "🎂 Сколько вам лет? (только число)"),
    "age_bad": ("❌ Yoshni 5 dan 99 gacha raqam bilan yozing.", "❌ Напишите возраст числом от 5 до 99."),
    "test_started": (
        "✅ Rahmat, <b>{name}</b>!\n\nTest boshlandi. Vaqt: <b>{minutes} daqiqa</b>. Omad! 🍀",
        "✅ Спасибо, <b>{name}</b>!\n\nТест начался. Время: <b>{minutes} минут</b>. Удачи! 🍀",
    ),
    "q_header": (
        "❓ <b>Savol {n}/{total}</b>   ⏳ {left} daq.\n\n{text}",
        "❓ <b>Вопрос {n}/{total}</b>   ⏳ {left} мин.\n\n{text}",
    ),
    "q_stale": ("Bu savol allaqachon javoblangan.", "На этот вопрос уже дан ответ."),
    "no_active": ("Faol test topilmadi.", "Активный тест не найден."),
    "resume_prompt": (
        "⏳ Sizda tugallanmagan test bor. Davom ettiramizmi?",
        "⏳ У вас есть незавершённый тест. Продолжим?",
    ),
    "btn_resume": ("▶️ Davom etish", "▶️ Продолжить"),
    "time_up": ("⌛ Vaqt tugadi. Test avtomatik yakunlandi.", "⌛ Время вышло. Тест завершён автоматически."),
    "pay_prompt": (
        "🎉 <b>Test yakunlandi!</b> Javoblaringiz hisoblandi va natija tayyor.\n\n"
        "Natijani ko'rish uchun <b>{price} so'm</b> to'lang:\n\n{cards}\n"
        "Karta egasi: <b>{owner}</b>\n\n"
        "💳 To'lovdan so'ng <b>chek rasmini (skrinshot)</b> shu yerga yuboring. "
        "Admin tasdiqlagach natijangiz ochiladi.",
        "🎉 <b>Тест завершён!</b> Ответы подсчитаны, результат готов.\n\n"
        "Чтобы увидеть результат, оплатите <b>{price} сум</b>:\n\n{cards}\n"
        "Владелец карты: <b>{owner}</b>\n\n"
        "💳 После оплаты отправьте сюда <b>фото чека (скриншот)</b>. "
        "После подтверждения админом результат откроется.",
    ),
    "btn_send_receipt": ("🧾 Chek yuborish", "🧾 Отправить чек"),
    "receipt_ask": (
        "🧾 To'lov chekining rasmini (skrinshot) yuboring.",
        "🧾 Отправьте фото чека об оплате (скриншот).",
    ),
    "receipt_wrong": (
        "❌ Iltimos, chekni <b>rasm</b> ko'rinishida yuboring.",
        "❌ Пожалуйста, отправьте чек в виде <b>фото</b>.",
    ),
    "receipt_dup": (
        "⚠️ Bu chek oldin ishlatilgan. Iltimos, o'zingizning chekingizni yuboring.",
        "⚠️ Этот чек уже использовался. Пожалуйста, отправьте свой чек.",
    ),
    "receipt_exists": (
        "⏳ Chekingiz allaqachon adminga yuborilgan, tasdiqlanishini kuting.",
        "⏳ Ваш чек уже отправлен админу, ожидайте подтверждения.",
    ),
    "receipt_ok": (
        "✅ Chekingiz adminga yuborildi!\n\n"
        "Kutish vaqtida kayfiyatingizni ko'taramiz 😊\n"
        "{praise}\n\n"
        "<b>Mini-vazifa:</b> {task}",
        "✅ Ваш чек отправлен админу!\n\n"
        "Пока ждёте, поднимем вам настроение 😊\n"
        "{praise}\n\n"
        "<b>Мини-задание:</b> {task}",
    ),
    "btn_task_done": ("✅ Bajardim", "✅ Выполнил(а)"),
    "btn_check": ("🔄 Holatni tekshirish", "🔄 Проверить статус"),
    "task_next": (
        "👏 Barakalla! Yana bittasi:\n\n<b>{task}</b>",
        "👏 Молодец! Ещё одно:\n\n<b>{task}</b>",
    ),
    "task_end": (
        "🌟 Ajoyib! Vazifalar tugadi. Natijangiz tasdiqlanishi bilan sizga yuboramiz. "
        "Xohlasangiz, holatni tekshirib ko'ring.",
        "🌟 Отлично! Задания закончились. Как только результат подтвердят, мы его пришлём. "
        "Если хотите, проверьте статус.",
    ),
    "status_wait": (
        "⏳ To'lov hali tekshirilmoqda. Odatda bu bir necha daqiqa oladi.",
        "⏳ Оплата ещё проверяется. Обычно это занимает несколько минут.",
    ),
    "pay_rejected": (
        "❌ To'lovingiz tasdiqlanmadi. Chek aniq ko'rinmagan yoki summa mos kelmagan bo'lishi mumkin. "
        "Iltimos, to'g'ri chekni qayta yuboring.",
        "❌ Ваша оплата не подтверждена. Возможно, чек нечёткий или сумма не совпала. "
        "Пожалуйста, отправьте правильный чек ещё раз.",
    ),
    "pay_approved": ("✅ To'lov tasdiqlandi! Natijangiz:", "✅ Оплата подтверждена! Ваш результат:"),
    "result": (
        "🏆 <b>IQ TEST NATIJASI</b>\n\n"
        "👤 {name}\n🎂 Yosh: {age}\n🆔 Natija raqami: <code>{rid}</code>\n"
        "📅 {date}\n\n"
        "🧠 <b>Taxminiy IQ: {iq}</b>\n"
        "📈 Daraja: <b>{level}</b>\n"
        "✔️ To'g'ri javoblar: {correct}/{total}\n\n"
        "<b>Toifalar bo'yicha:</b>\n{cats}\n\n"
        "💪 Eng kuchli tomoningiz: <b>{best}</b>\n"
        "🎯 Rivojlantirish mumkin: <b>{worst}</b>\n\n"
        "⚠️ Bu taxminiy natija, rasmiy psixologik o'lchov emas.",
        "🏆 <b>РЕЗУЛЬТАТ IQ-ТЕСТА</b>\n\n"
        "👤 {name}\n🎂 Возраст: {age}\n🆔 Номер результата: <code>{rid}</code>\n"
        "📅 {date}\n\n"
        "🧠 <b>Приблизительный IQ: {iq}</b>\n"
        "📈 Уровень: <b>{level}</b>\n"
        "✔️ Правильных ответов: {correct}/{total}\n\n"
        "<b>По категориям:</b>\n{cats}\n\n"
        "💪 Сильная сторона: <b>{best}</b>\n"
        "🎯 Можно развивать: <b>{worst}</b>\n\n"
        "⚠️ Это приблизительный результат, а не официальное психологическое измерение.",
    ),
    "level_names": (
        {"Juda yuqori": "Juda yuqori", "Yuqori": "Yuqori", "O'rtachadan yuqori": "O'rtachadan yuqori",
         "O'rtacha": "O'rtacha", "O'rtachadan past": "O'rtachadan past", "Past": "Past"},
        {"Juda yuqori": "Очень высокий", "Yuqori": "Высокий", "O'rtachadan yuqori": "Выше среднего",
         "O'rtacha": "Средний", "O'rtachadan past": "Ниже среднего", "Past": "Низкий"},
    ),
    "cat_names": (
        {"series": "Raqamlar ketma-ketligi", "logic": "Mantiqiy fikrlash", "verbal": "So'z va tushunchalar",
         "space": "Fazoviy tasavvur", "math": "Matematik fikrlash"},
        {"series": "Числовые ряды", "logic": "Логика", "verbal": "Слова и понятия",
         "space": "Пространственное мышление", "math": "Математическое мышление"},
    ),
    "btn_cert": ("🎓 Sertifikat olish (bepul)", "🎓 Получить сертификат (бесплатно)"),
    "cert_requested": (
        "🎓 Sertifikat so'rovingiz adminga yuborildi. Tayyor bo'lgach shu yerga yuboriladi.",
        "🎓 Ваш запрос на сертификат отправлен админу. Когда будет готов, он придёт сюда.",
    ),
    "cert_exists": (
        "ℹ️ Bu natija uchun sertifikat so'rovi allaqachon yuborilgan.",
        "ℹ️ Запрос сертификата для этого результата уже отправлен.",
    ),
    "cert_caption": (
        "🎓 Sizning sertifikatingiz tayyor! Tabriklaymiz, <b>{name}</b>! 🎉",
        "🎓 Ваш сертификат готов! Поздравляем, <b>{name}</b>! 🎉",
    ),
    "my_results_empty": ("Sizda hali natijalar yo'q.", "У вас пока нет результатов."),
    "my_results_head": ("📊 <b>Natijalaringiz:</b>", "📊 <b>Ваши результаты:</b>"),
    "my_result_line_paid": ("{rid} · {date} · IQ {iq}", "{rid} · {date} · IQ {iq}"),
    "my_result_line_unpaid": (
        "{rid} · {date} · to'lov kutilmoqda",
        "{rid} · {date} · ожидает оплаты",
    ),

    # ---------- ustozlar ----------
    "teacher_intro": (
        "🏫 <b>Ustozlar va o'quv markazlari uchun</b>\n\n"
        "• Siz maxsus havola olasiz va uni o'quvchilaringizga yuborasiz.\n"
        "• O'quvchilar testni <b>bepul</b> topshiradi.\n"
        "• Havola orqali <b>{max_students} tagacha</b> o'quvchi qo'shila oladi.\n"
        "• Barcha o'quvchilarning ism va ballari sizga ko'rinib turadi.\n"
        "• Eng yuqori ball olgan o'quvchi nomiga <b>sertifikat</b> beriladi.\n\n"
        "💰 Narxi: <b>{price} so'm</b> (havolani olishdan oldin to'lanadi).",
        "🏫 <b>Для учителей и учебных центров</b>\n\n"
        "• Вы получаете специальную ссылку и отправляете её ученикам.\n"
        "• Ученики проходят тест <b>бесплатно</b>.\n"
        "• По ссылке могут присоединиться <b>до {max_students}</b> учеников.\n"
        "• Вам видны имена и баллы всех учеников.\n"
        "• На имя ученика с самым высоким баллом выдаётся <b>сертификат</b>.\n\n"
        "💰 Стоимость: <b>{price} сум</b> (оплата до получения ссылки).",
    ),
    "btn_teacher_new": ("➕ Yangi havola yaratish", "➕ Создать новую ссылку"),
    "btn_teacher_mine": ("📋 Mening havolalarim", "📋 Мои ссылки"),
    "teacher_ask_name": (
        "✍️ Ismingiz va familiyangizni yozing (ustoz sifatida).",
        "✍️ Напишите своё имя и фамилию (как учителя).",
    ),
    "teacher_ask_org": (
        "🏫 Maktab, o'quv markazi yoki sinf/guruh nomini yozing.\nMasalan: <i>12-maktab, 9-A sinf</i>",
        "🏫 Напишите название школы, учебного центра или класса/группы.\nНапример: <i>Школа 12, 9-А класс</i>",
    ),
    "text_bad": ("❌ Iltimos, matn yozing (kamida 2 ta belgi).", "❌ Пожалуйста, напишите текст (минимум 2 символа)."),
    "teacher_pay_prompt": (
        "💳 Havola yaratish narxi: <b>{price} so'm</b>.\n\n{cards}\n"
        "Karta egasi: <b>{owner}</b>\n\n"
        "To'lovdan so'ng <b>chek rasmini</b> yuboring. Admin tasdiqlagach havolangiz tayyor bo'ladi.",
        "💳 Стоимость создания ссылки: <b>{price} сум</b>.\n\n{cards}\n"
        "Владелец карты: <b>{owner}</b>\n\n"
        "После оплаты отправьте <b>фото чека</b>. После подтверждения админом ссылка будет готова.",
    ),
    "teacher_receipt_ok": (
        "✅ Chekingiz adminga yuborildi. Tasdiqlangach havolangiz shu yerga keladi.",
        "✅ Ваш чек отправлен админу. После подтверждения ссылка придёт сюда.",
    ),
    "teacher_ready": (
        "🎉 <b>To'lov tasdiqlandi!</b> Havolangiz tayyor:\n\n{link}\n\n"
        "Bu havolani o'quvchilaringizga yuboring (<b>{max_students} tagacha</b> o'quvchi qo'shila oladi).",
        "🎉 <b>Оплата подтверждена!</b> Ваша ссылка готова:\n\n{link}\n\n"
        "Отправьте её ученикам (присоединиться могут <b>до {max_students}</b> учеников).",
    ),
    "teacher_panel": (
        "🏫 <b>{org}</b>\n"
        "Holat: <b>{status}</b>\n"
        "Qo'shilganlar: <b>{taken}/{max_students}</b>\n"
        "Tugatganlar: <b>{done}</b>\n\n"
        "🔗 {link}\n\n"
        "<b>O'quvchilar (ball bo'yicha):</b>\n{rows}",
        "🏫 <b>{org}</b>\n"
        "Статус: <b>{status}</b>\n"
        "Присоединились: <b>{taken}/{max_students}</b>\n"
        "Завершили: <b>{done}</b>\n\n"
        "🔗 {link}\n\n"
        "<b>Ученики (по баллам):</b>\n{rows}",
    ),
    "teacher_status": (
        {"active": "faol", "closed": "yopilgan", "awaiting_payment": "to'lov kutilmoqda"},
        {"active": "активна", "closed": "закрыта", "awaiting_payment": "ожидает оплаты"},
    ),
    "teacher_row_done": (
        "{i}. {name}: IQ <b>{iq}</b> ({correct}/{total})",
        "{i}. {name}: IQ <b>{iq}</b> ({correct}/{total})",
    ),
    "teacher_row_wait": ("{i}. {name}: ⏳ test topshirmoqda", "{i}. {name}: ⏳ проходит тест"),
    "teacher_row_stopped": (
        "{i}. {name}: tugatmadi ({answered}/{total} javob)",
        "{i}. {name}: не завершил(а) ({answered}/{total} ответов)",
    ),
    "teacher_no_students": ("Hali hech kim qo'shilmagan.", "Пока никто не присоединился."),
    "btn_refresh": ("🔄 Yangilash", "🔄 Обновить"),
    "btn_get_results": ("🏁 Natijalarni olish (testni to'xtatish)", "🏁 Получить результаты (остановить тест)"),
    "teacher_stop_confirm": (
        "⚠️ Hozir test topshirayotgan o'quvchilar to'xtatiladi va havola yopiladi. Davom etamizmi?",
        "⚠️ Ученики, проходящие тест сейчас, будут остановлены, а ссылка закроется. Продолжить?",
    ),
    "btn_yes": ("✅ Ha", "✅ Да"),
    "btn_no": ("❌ Yo'q", "❌ Нет"),
    "teacher_stopped": (
        "🏁 Havola yopildi. Yakuniy natijalar:",
        "🏁 Ссылка закрыта. Итоговые результаты:",
    ),
    "btn_teacher_cert": (
        "🎓 Eng yuqori ball uchun sertifikat (bepul)",
        "🎓 Сертификат за высший балл (бесплатно)",
    ),
    "teacher_cert_none": (
        "Sertifikat uchun kamida bitta tugatilgan test kerak.",
        "Для сертификата нужен хотя бы один завершённый тест.",
    ),
    "teacher_cert_requested": (
        "🎓 Eng yuqori ball olgan o'quvchi <b>{name}</b> (IQ {iq}) uchun sertifikat so'rovi adminga yuborildi.",
        "🎓 Запрос сертификата для ученика с высшим баллом <b>{name}</b> (IQ {iq}) отправлен админу.",
    ),
    "teacher_cert_sent": (
        "🎓 O'quvchi <b>{name}</b> uchun sertifikat tayyor:",
        "🎓 Сертификат для ученика <b>{name}</b> готов:",
    ),
    "student_invite": (
        "👋 Ustoz <b>{teacher}</b> ({org}) sizni IQ testga taklif qildi.\n\n"
        "• 30 ta savol, {minutes} daqiqa\n• Siz uchun <b>bepul</b>\n• Natija ustozingizga yuboriladi",
        "👋 Учитель <b>{teacher}</b> ({org}) приглашает вас пройти IQ-тест.\n\n"
        "• 30 вопросов, {minutes} минут\n• Для вас <b>бесплатно</b>\n• Результат будет отправлен учителю",
    ),
    "student_full": (
        "😔 Kechirasiz, bu havola uchun joylar to'lgan ({max_students}/{max_students}).\n\n"
        "Testni mustaqil topshirishni tavsiya qilamiz: asosiy menyudan «IQ testni boshlash» ni tanlang.",
        "😔 К сожалению, места по этой ссылке закончились ({max_students}/{max_students}).\n\n"
        "Рекомендуем пройти тест самостоятельно: выберите «Начать IQ-тест» в главном меню.",
    ),
    "student_closed": (
        "🔒 Bu havola yopilgan. Testni mustaqil topshirishingiz mumkin.",
        "🔒 Эта ссылка закрыта. Вы можете пройти тест самостоятельно.",
    ),
    "student_invalid": ("❌ Havola noto'g'ri yoki eskirgan.", "❌ Ссылка неверна или устарела."),
    "student_already": (
        "ℹ️ Siz bu havola orqali testni allaqachon boshlagansiz.",
        "ℹ️ Вы уже начинали тест по этой ссылке.",
    ),
    "student_done": (
        "✅ Test yakunlandi! Natijangiz ustozingizga yuborildi. Rahmat!",
        "✅ Тест завершён! Ваш результат отправлен учителю. Спасибо!",
    ),
    "student_stopped": (
        "🏁 Ustozingiz testni yakunladi. Natijangiz hisobga olindi.",
        "🏁 Учитель завершил тест. Ваш результат учтён.",
    ),
    "teacher_notify_done": (
        "📥 {name} testni tugatdi: IQ <b>{iq}</b> ({correct}/{total}).",
        "📥 {name} завершил(а) тест: IQ <b>{iq}</b> ({correct}/{total}).",
    ),
    "banned": ("🚫 Sizga botdan foydalanish cheklangan.", "🚫 Вам ограничен доступ к боту."),
    "error": (
        "⚠️ Xatolik yuz berdi. Iltimos, /start ni bosib qayta urinib ko'ring.",
        "⚠️ Произошла ошибка. Нажмите /start и попробуйте снова.",
    ),
}

# To'lovdan keyingi maqtovlar va mini-vazifalar
PRAISES = [
    ("Siz bu testni jiddiy va diqqat bilan yechdingiz, bu juda yaxshi fazilat! 👏",
     "Вы решали тест серьёзно и внимательно, это отличное качество! 👏"),
    ("Qiziquvchan odamlar hayotda ko'proq yutadi, siz ulardan birisiz! 🌟",
     "Любознательные люди чаще побеждают в жизни, а вы один из них! 🌟"),
    ("O'zingizni sinashga jur'at qilish allaqachon katta qadam! 💪",
     "Решиться проверить себя уже большой шаг! 💪"),
]

TASKS = [
    ("💧 Bir stakan suv iching.", "💧 Выпейте стакан воды."),
    ("🙆 Ikki marta chuqur nafas oling va yelkangizni bo'shashtiring.",
     "🙆 Сделайте два глубоких вдоха и расслабьте плечи."),
    ("😊 Yaqin odamingizga bitta iliq so'z ayting.", "😊 Скажите близкому человеку тёплое слово."),
    ("🚶 Ikki daqiqa o'rningizdan turib yurib keling.", "🚶 Встаньте и пройдитесь две минуты."),
]


def tr(lang: str, key: str, **kw):
    """Kalit bo'yicha matn. Lug'at ko'rinishidagi kalitlar (level_names va h.k.) o'zi qaytariladi."""
    pair = T[key]
    val = pair[1] if lang == "ru" else pair[0]
    if isinstance(val, dict):
        return val
    # standart qiymatlar
    kw.setdefault("price", money(config.PRICE_USER))
    kw.setdefault("minutes", config.TEST_MINUTES)
    kw.setdefault("max_students", config.TEACHER_MAX_STUDENTS)
    return val.format(**kw) if kw else val


def cards_text() -> str:
    return "\n".join(f"{name}: <code>{num}</code>" for name, num in config.CARDS) + "\n"
