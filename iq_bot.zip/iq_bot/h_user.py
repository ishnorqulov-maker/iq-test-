"""Oddiy foydalanuvchi oqimi: til, obuna, test, to'lov cheki, natija, sertifikat so'rovi."""
import config
import core
import db
import scoring
from h_teacher import student_entry
from texts import money, tr
from util import (back_menu_kb, edit_or_send, esc, fmt_dt, kb, lang_of, menu_kb,
                  missing_channels, notify_admins, parse_name, safe_send)

TOTAL = core.TOTAL


# ---------------------------------------------------------------- kirish
async def gate(update, context) -> bool:
    """Til tanlangan va majburiy kanallarga obuna bo'lingan bo'lsagina True."""
    u = update.effective_user
    db.upsert_user(u.id, u.username, u.first_name)
    lang = db.get_lang(u.id)
    if not lang:
        await edit_or_send(update, context, tr("uz", "choose_lang"),
                           kb([[("🇺🇿 O'zbekcha", "lang:uz"), ("🇷🇺 Русский", "lang:ru")]]))
        return False
    miss = await missing_channels(context.bot, u.id)
    if miss:
        rows = [[(tr(lang, "btn_channel", title=ch["title"] or ch["chat_id"]), "url:" + ch["link"])]
                for ch in miss if ch["link"]]
        rows.append([(tr(lang, "btn_sub_done"), "sub:check")])
        await edit_or_send(update, context, tr(lang, "sub_required"), kb(rows))
        return False
    return True


async def proceed(update, context):
    if not await gate(update, context):
        return
    code = context.user_data.pop("join_code", None)
    if code:
        await student_entry(update, context, code)
        return
    await show_menu(update, context)


async def show_menu(update, context):
    lang = lang_of(update.effective_user.id)
    await edit_or_send(update, context, tr(lang, "menu_title"), menu_kb(lang))


async def cmd_start(update, context):
    context.user_data.pop("state", None)
    if context.args and context.args[0].startswith("t_"):
        context.user_data["join_code"] = context.args[0][2:]
    await proceed(update, context)


async def cb_lang(update, context):
    q = update.callback_query
    await q.answer()
    db.upsert_user(q.from_user.id, q.from_user.username, q.from_user.first_name)
    db.set_lang(q.from_user.id, q.data.split(":")[1])
    await proceed(update, context)


async def cb_change_lang(update, context):
    await update.callback_query.answer()
    await edit_or_send(update, context, tr("uz", "choose_lang"),
                       kb([[("🇺🇿 O'zbekcha", "lang:uz"), ("🇷🇺 Русский", "lang:ru")]]))


async def cb_sub_check(update, context):
    q = update.callback_query
    miss = await missing_channels(context.bot, q.from_user.id)
    if miss:
        await q.answer(tr(lang_of(q.from_user.id), "sub_missing"), show_alert=True)
        return
    await q.answer()
    await proceed(update, context)


async def cb_menu(update, context):
    await update.callback_query.answer()
    context.user_data.pop("state", None)
    if await gate(update, context):
        await show_menu(update, context)


async def cb_help(update, context):
    await update.callback_query.answer()
    lang = lang_of(update.effective_user.id)
    await edit_or_send(update, context, tr(lang, "help"), back_menu_kb(lang))


# ---------------------------------------------------------------- ro'yxatdan o'tish
async def cb_test_start(update, context):
    q = update.callback_query
    await q.answer()
    if not await gate(update, context):
        return
    uid = q.from_user.id
    lang = lang_of(uid)
    a = db.active_attempt(uid)
    if a:
        if a["deadline"] < db.now():
            await core.finalize(context.bot, a["id"], "expired")
            return
        await edit_or_send(update, context, tr(lang, "resume_prompt"),
                           kb([[(tr(lang, "btn_resume"), "test:resume")]]))
        return
    context.user_data["reg"] = {"kind": "user"}
    context.user_data["state"] = "name"
    await edit_or_send(update, context, tr(lang, "test_intro") + "\n\n" + tr(lang, "ask_name"))


async def cb_test_resume(update, context):
    q = update.callback_query
    await q.answer()
    a = db.active_attempt(q.from_user.id)
    if not a:
        await safe_send(context.bot, q.from_user.id, tr(lang_of(q.from_user.id), "no_active"))
        return
    if a["deadline"] < db.now():
        await core.finalize(context.bot, a["id"], "expired")
        return
    await core.send_question(context.bot, a)


async def on_name(update, context):
    uid = update.effective_user.id
    lang = lang_of(uid)
    name = parse_name(update.message.text)
    if not name:
        await safe_send(context.bot, uid, tr(lang, "name_bad"))
        return
    context.user_data["reg"]["name"] = name
    context.user_data["state"] = "age"
    await safe_send(context.bot, uid, tr(lang, "ask_age"))


async def on_age(update, context):
    uid = update.effective_user.id
    lang = lang_of(uid)
    txt = (update.message.text or "").strip()
    if not txt.isdigit() or not (5 <= int(txt) <= 99):
        await safe_send(context.bot, uid, tr(lang, "age_bad"))
        return
    reg = context.user_data.pop("reg", None)
    context.user_data.pop("state", None)
    if not reg or "name" not in reg:
        await safe_send(context.bot, uid, tr(lang, "error"))
        return
    age = int(txt)
    existing = db.active_attempt(uid)
    if existing:  # ikki marta ro'yxatdan o'tishga yo'l qo'ymaymiz
        await core.send_question(context.bot, existing)
        return
    if reg["kind"] == "student":
        aid = db.claim_slot(uid, reg["teacher_id"], reg["name"], age)
        if aid is None:
            t = db.get_teacher(reg["teacher_id"])
            await safe_send(context.bot, uid, tr(lang, "student_full"),
                            reply_markup=menu_kb(lang))
            return
    else:
        aid = db.create_attempt(uid, "user", None, reg["name"], age)
    await safe_send(context.bot, uid, tr(lang, "test_started", name=esc(reg["name"])))
    await core.send_question(context.bot, db.get_attempt(aid))


# ---------------------------------------------------------------- javob berish
async def cb_answer(update, context):
    q = update.callback_query
    try:
        _, aid, pos, shown = q.data.split(":")
        aid, pos, shown = int(aid), int(pos), int(shown)
    except ValueError:
        await q.answer()
        return
    a = db.get_attempt(aid)
    if not a or a["user_id"] != q.from_user.id:
        await q.answer()
        return
    lang = lang_of(a["user_id"])
    if a["status"] != "in_progress":
        await q.answer(tr(lang, "no_active"), show_alert=True)
        return
    if a["deadline"] < db.now():
        await q.answer()
        await core.finalize(context.bot, aid, "expired")
        return
    if a["pos"] != pos or not (0 <= shown < 4):
        await q.answer(tr(lang, "q_stale"), show_alert=True)
        return
    q_index, _, _, mapping = scoring.build_view(a["seed"], pos, lang)
    chosen = mapping[shown]
    db.record_answer(aid, q_index, chosen, scoring.is_correct(q_index, chosen))
    await q.answer()
    a = db.get_attempt(aid)
    if a["pos"] >= TOTAL:
        try:
            await q.edit_message_reply_markup(reply_markup=None)
        except Exception:
            pass
        await core.finalize(context.bot, aid, "finished")
    else:
        await core.send_question(context.bot, a, query=q)


# ---------------------------------------------------------------- to'lov cheki
def guess_receipt_target(uid: int):
    r = db.one(
        "SELECT id FROM attempts WHERE user_id=? AND kind='user' AND status!='in_progress' "
        "AND pay_status IN ('none','rejected') ORDER BY id DESC LIMIT 1", (uid,))
    if r:
        return {"kind": "result", "ref": r["id"]}
    r = db.one("SELECT id FROM teachers WHERE user_id=? AND status='awaiting_payment' "
               "ORDER BY id DESC LIMIT 1", (uid,))
    if r:
        return {"kind": "teacher", "ref": r["id"]}
    return None


async def cb_rcpt(update, context):
    q = update.callback_query
    await q.answer()
    lang = lang_of(q.from_user.id)
    aid = int(q.data.split(":")[1])
    a = db.get_attempt(aid)
    if not a or a["user_id"] != q.from_user.id or a["status"] == "in_progress":
        return
    if a["pay_status"] == "approved":
        await core.show_result(context.bot, a)
        return
    if a["pay_status"] == "awaiting":
        await safe_send(context.bot, q.from_user.id, tr(lang, "receipt_exists"))
        return
    context.user_data["receipt"] = {"kind": "result", "ref": aid}
    context.user_data["state"] = "receipt"
    await safe_send(context.bot, q.from_user.id, tr(lang, "receipt_ask"))


async def on_receipt(update, context) -> bool:
    """Chek rasmini qabul qiladi. Xabar chekka tegishli bo'lsa True qaytaradi."""
    u = update.effective_user
    lang = lang_of(u.id)
    msg = update.message
    target = context.user_data.get("receipt") or guess_receipt_target(u.id)
    if not target:
        # Chek allaqachon yuborilgan va tasdiq kutilmoqda bo'lsa, buni aytamiz
        if msg.photo and db.one("SELECT 1 FROM payments WHERE user_id=? AND status='pending'", (u.id,)):
            await safe_send(context.bot, u.id, tr(lang, "receipt_exists"))
            return True
        return False
    if not msg.photo:
        await safe_send(context.bot, u.id, tr(lang, "receipt_wrong"))
        return True

    kind, ref = target["kind"], target["ref"]
    if kind == "result":
        a = db.get_attempt(ref)
        if not a or a["user_id"] != u.id or a["pay_status"] not in ("none", "rejected"):
            return False
        amount, who = config.PRICE_USER, a["full_name"]
    else:
        t = db.get_teacher(ref)
        if not t or t["user_id"] != u.id or t["status"] != "awaiting_payment":
            return False
        amount, who = config.PRICE_TEACHER, f"{t['full_name']} ({t['org']})"

    if db.has_pending_payment(kind, ref):
        await safe_send(context.bot, u.id, tr(lang, "receipt_exists"))
        return True
    ph = msg.photo[-1]
    pid = db.create_payment(u.id, kind, ref, amount, ph.file_id, ph.file_unique_id)
    if pid is None:
        await safe_send(context.bot, u.id, tr(lang, "receipt_dup"))
        return True

    context.user_data.pop("receipt", None)
    context.user_data.pop("state", None)
    if kind == "result":
        db.set_attempt_pay(ref, "awaiting")

    label = "IQ test natijasi" if kind == "result" else "Ustoz havolasi"
    uname = f"@{u.username}" if u.username else "yo'q"
    await notify_admins(
        context.bot,
        f"💳 <b>Yangi to'lov #{pid}</b>\n"
        f"Turi: {label}\nSumma: <b>{money(amount)} so'm</b>\n"
        f"Ism: {esc(who)}\nTelegram: {esc(uname)}\nID: <code>{u.id}</code>",
        reply_markup=kb([[("✅ Tasdiqlash", f"a:payok:{pid}"), ("❌ Rad etish", f"a:payno:{pid}")]]),
        photo=ph.file_id,
    )

    if kind == "teacher":
        await safe_send(context.bot, u.id, tr(lang, "teacher_receipt_ok"), reply_markup=back_menu_kb(lang))
    else:
        await safe_send(
            context.bot, u.id,
            tr(lang, "receipt_ok", praise=core.pick_praise(lang), task=core.task_text(lang, 0)),
            reply_markup=kb([[(tr(lang, "btn_task_done"), f"task:{ref}:0")],
                             [(tr(lang, "btn_check"), f"chk:{ref}")]]),
        )
    return True


async def cb_task(update, context):
    q = update.callback_query
    await q.answer()
    lang = lang_of(q.from_user.id)
    _, aid, i = q.data.split(":")
    aid, i = int(aid), int(i)
    check_btn = [(tr(lang, "btn_check"), f"chk:{aid}")]
    if i + 1 < 2:
        await edit_or_send(update, context, tr(lang, "task_next", task=core.task_text(lang, i + 1)),
                           kb([[(tr(lang, "btn_task_done"), f"task:{aid}:{i + 1}")], check_btn]))
    else:
        await edit_or_send(update, context, tr(lang, "task_end"), kb([check_btn]))


async def cb_check(update, context):
    q = update.callback_query
    await q.answer()
    lang = lang_of(q.from_user.id)
    aid = int(q.data.split(":")[1])
    a = db.get_attempt(aid)
    if not a or a["user_id"] != q.from_user.id:
        return
    if a["pay_status"] == "approved":
        await core.show_result(context.bot, a)
    elif a["pay_status"] == "rejected":
        await safe_send(context.bot, q.from_user.id, tr(lang, "pay_rejected"),
                        reply_markup=kb([[(tr(lang, "btn_send_receipt"), f"rcpt:{aid}")]]))
    else:
        await safe_send(context.bot, q.from_user.id, tr(lang, "status_wait"),
                        reply_markup=kb([[(tr(lang, "btn_check"), f"chk:{aid}")]]))


# ---------------------------------------------------------------- natijalar
async def cb_results(update, context):
    q = update.callback_query
    await q.answer()
    lang = lang_of(q.from_user.id)
    rows_db = [a for a in db.user_attempts(q.from_user.id) if a["status"] != "in_progress"]
    if not rows_db:
        await edit_or_send(update, context, tr(lang, "my_results_empty"), back_menu_kb(lang))
        return
    rows = []
    for a in rows_db[:10]:
        if a["pay_status"] == "approved":
            label = tr(lang, "my_result_line_paid", rid=a["result_id"], date=fmt_dt(a["finished_at"]), iq=a["iq"])
        else:
            label = tr(lang, "my_result_line_unpaid", rid=a["result_id"], date=fmt_dt(a["finished_at"]))
        rows.append([(label, f"res:{a['id']}")])
    rows.append([(tr(lang, "btn_menu"), "menu")])
    await edit_or_send(update, context, tr(lang, "my_results_head"), kb(rows))


async def cb_result_open(update, context):
    q = update.callback_query
    await q.answer()
    aid = int(q.data.split(":")[1])
    a = db.get_attempt(aid)
    if not a or a["user_id"] != q.from_user.id or a["status"] == "in_progress":
        return
    lang = lang_of(q.from_user.id)
    if a["pay_status"] == "approved":
        await core.show_result(context.bot, a)
    elif a["pay_status"] == "awaiting":
        await safe_send(context.bot, q.from_user.id, tr(lang, "status_wait"),
                        reply_markup=kb([[(tr(lang, "btn_check"), f"chk:{aid}")]]))
    else:
        await safe_send(context.bot, q.from_user.id, core.pay_prompt_text(lang, config.PRICE_USER),
                        reply_markup=kb([[(tr(lang, "btn_send_receipt"), f"rcpt:{aid}")]]))


# ---------------------------------------------------------------- sertifikat so'rovi
async def cb_cert(update, context):
    q = update.callback_query
    await q.answer()
    lang = lang_of(q.from_user.id)
    aid = int(q.data.split(":")[1])
    a = db.get_attempt(aid)
    if not a or a["user_id"] != q.from_user.id or a["pay_status"] != "approved":
        return
    cid = db.create_cert(q.from_user.id, aid, None, a["full_name"])
    if cid is None:
        await safe_send(context.bot, q.from_user.id, tr(lang, "cert_exists"))
        return
    await safe_send(context.bot, q.from_user.id, tr(lang, "cert_requested"), reply_markup=back_menu_kb(lang))
    await notify_admins(
        context.bot,
        f"🎓 <b>Sertifikat so'rovi #{cid}</b>\n"
        f"Ism: {esc(a['full_name'])}\nYosh: {a['age']}\n"
        f"IQ: <b>{a['iq']}</b> · {a['correct']}/{TOTAL}\n"
        f"Natija raqami: <code>{a['result_id']}</code>\nSana: {fmt_dt(a['finished_at'])}\n"
        f"Foydalanuvchi ID: <code>{q.from_user.id}</code>",
        reply_markup=kb([[("📤 Sertifikat yuborish", f"a:certsend:{cid}")]]),
    )
