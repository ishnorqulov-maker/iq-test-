"""SQLite ma'lumotlar bazasi. Barcha vaqtlar UTC epoch (soniya) ko'rinishida saqlanadi."""
import json
import os
import random
import secrets
import sqlite3
import threading
import time

import config

_lock = threading.RLock()
_conn = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    user_id INTEGER PRIMARY KEY,
    username TEXT, first_name TEXT,
    joined_at INTEGER, last_seen INTEGER,
    banned INTEGER DEFAULT 0,
    lang TEXT
);
CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY, added_at INTEGER);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS channels(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id TEXT NOT NULL, title TEXT, link TEXT
);
CREATE TABLE IF NOT EXISTS teachers(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL, full_name TEXT, org TEXT,
    code TEXT UNIQUE,
    status TEXT NOT NULL DEFAULT 'awaiting_payment',  -- awaiting_payment | active | closed
    max_students INTEGER NOT NULL,
    created_at INTEGER, activated_at INTEGER, closed_at INTEGER
);
CREATE TABLE IF NOT EXISTS attempts(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    kind TEXT NOT NULL,                 -- user | student
    teacher_id INTEGER,
    full_name TEXT, age INTEGER,
    seed INTEGER, answers TEXT DEFAULT '{}',
    pos INTEGER DEFAULT 0,
    started_at INTEGER, deadline INTEGER, finished_at INTEGER,
    status TEXT NOT NULL DEFAULT 'in_progress',  -- in_progress | finished | expired | stopped
    answered INTEGER DEFAULT 0, correct INTEGER DEFAULT 0,
    score_pct REAL, iq INTEGER,
    pay_status TEXT NOT NULL DEFAULT 'none',     -- none | awaiting | approved | rejected
    result_id TEXT
);
CREATE INDEX IF NOT EXISTS ix_att_user ON attempts(user_id);
CREATE INDEX IF NOT EXISTS ix_att_teacher ON attempts(teacher_id);
CREATE TABLE IF NOT EXISTS payments(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    kind TEXT NOT NULL,                 -- result | teacher
    ref_id INTEGER NOT NULL,            -- attempts.id yoki teachers.id
    amount INTEGER, file_id TEXT, file_unique_id TEXT,
    status TEXT NOT NULL DEFAULT 'pending',      -- pending | approved | rejected
    created_at INTEGER, decided_at INTEGER, decided_by INTEGER
);
CREATE TABLE IF NOT EXISTS certs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    attempt_id INTEGER NOT NULL,
    teacher_id INTEGER,
    full_name TEXT,
    status TEXT NOT NULL DEFAULT 'pending',      -- pending | sent
    created_at INTEGER, sent_at INTEGER,
    UNIQUE(attempt_id)
);
"""


def now() -> int:
    return int(time.time())


def conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        os.makedirs(os.path.dirname(config.DB_PATH) or ".", exist_ok=True)
        _conn = sqlite3.connect(config.DB_PATH, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
    return _conn


def init() -> None:
    with _lock:
        conn().executescript(SCHEMA)
        conn().commit()


def run(sql: str, args=()) -> int:
    with _lock:
        cur = conn().execute(sql, args)
        conn().commit()
        return cur.lastrowid


def all_(sql: str, args=()):
    with _lock:
        return conn().execute(sql, args).fetchall()


def one(sql: str, args=()):
    with _lock:
        return conn().execute(sql, args).fetchone()


# ---------------- foydalanuvchilar, adminlar, sozlamalar ----------------
def upsert_user(user_id: int, username, first_name) -> None:
    run(
        "INSERT INTO users(user_id, username, first_name, joined_at, last_seen) "
        "VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET "
        "username=excluded.username, first_name=excluded.first_name, last_seen=excluded.last_seen",
        (user_id, username, first_name, now(), now()),
    )


def user_ids():
    return [r["user_id"] for r in all_("SELECT user_id FROM users WHERE banned=0")]


def get_lang(user_id: int):
    """Tanlangan til ('uz' yoki 'ru'); hali tanlanmagan bo'lsa None."""
    r = one("SELECT lang FROM users WHERE user_id=?", (user_id,))
    return r["lang"] if r and r["lang"] in ("uz", "ru") else None


def set_lang(user_id: int, lang: str) -> None:
    run("UPDATE users SET lang=? WHERE user_id=?", (lang, user_id))


def is_admin(user_id: int) -> bool:
    if user_id in config.OWNER_IDS:
        return True
    return one("SELECT 1 FROM admins WHERE user_id=?", (user_id,)) is not None


def admin_ids():
    ids = set(config.OWNER_IDS)
    ids.update(r["user_id"] for r in all_("SELECT user_id FROM admins"))
    return sorted(ids)


def add_admin(user_id: int) -> None:
    run("INSERT OR IGNORE INTO admins(user_id, added_at) VALUES(?,?)", (user_id, now()))


def remove_admin(user_id: int) -> bool:
    if user_id in config.OWNER_IDS:
        return False
    run("DELETE FROM admins WHERE user_id=?", (user_id,))
    return True


def get_setting(key: str, default=None):
    r = one("SELECT value FROM settings WHERE key=?", (key,))
    return r["value"] if r else default


def set_setting(key: str, value: str) -> None:
    run(
        "INSERT INTO settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )


# ---------------- majburiy obuna kanallari ----------------
def add_channel(chat_id: str, title: str, link: str) -> int:
    return run("INSERT INTO channels(chat_id,title,link) VALUES(?,?,?)", (chat_id, title, link))


def channels():
    return all_("SELECT * FROM channels ORDER BY id")


def del_channel(channel_id: int) -> None:
    run("DELETE FROM channels WHERE id=?", (channel_id,))


# ---------------- urinishlar (testlar) ----------------
def create_attempt(user_id, kind, teacher_id, full_name, age) -> int:
    t = now()
    return run(
        "INSERT INTO attempts(user_id,kind,teacher_id,full_name,age,seed,started_at,deadline,pay_status) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (
            user_id, kind, teacher_id, full_name, age,
            random.randrange(1, 2**31), t, t + config.TEST_MINUTES * 60,
            "approved" if kind == "student" else "none",
        ),
    )


def get_attempt(attempt_id: int):
    return one("SELECT * FROM attempts WHERE id=?", (attempt_id,))


def active_attempt(user_id: int):
    return one(
        "SELECT * FROM attempts WHERE user_id=? AND status='in_progress' ORDER BY id DESC LIMIT 1",
        (user_id,),
    )


def user_attempts(user_id: int):
    return all_(
        "SELECT * FROM attempts WHERE user_id=? AND kind='user' ORDER BY id DESC", (user_id,)
    )


def record_answer(attempt_id: int, q_index: int, chosen: int, is_correct: bool) -> None:
    """Javobni saqlaydi va pozitsiyani oldinga suradi."""
    with _lock:
        a = get_attempt(attempt_id)
        answers = json.loads(a["answers"] or "{}")
        if str(q_index) in answers:
            return
        answers[str(q_index)] = chosen
        conn().execute(
            "UPDATE attempts SET answers=?, pos=pos+1, answered=answered+1, correct=correct+? WHERE id=?",
            (json.dumps(answers), 1 if is_correct else 0, attempt_id),
        )
        conn().commit()


def finish_attempt(attempt_id: int, status: str, score_pct: float, iq: int) -> bool:
    """Urinishni yakunlaydi. Faqat 'in_progress' holatdagi urinish yakunlanadi, shuning uchun
    oxirgi javob va vaqt tugashi bir vaqtda kelsa ham natija bir marta hisoblanadi."""
    with _lock:
        cur = conn().execute(
            "UPDATE attempts SET status=?, finished_at=?, score_pct=?, iq=?, "
            "result_id=COALESCE(result_id,?) WHERE id=? AND status='in_progress'",
            (status, now(), score_pct, iq, f"R{attempt_id:05d}", attempt_id),
        )
        conn().commit()
        return cur.rowcount == 1


def set_attempt_pay(attempt_id: int, pay_status: str) -> None:
    run("UPDATE attempts SET pay_status=? WHERE id=?", (pay_status, attempt_id))


def overdue_attempts():
    return all_("SELECT * FROM attempts WHERE status='in_progress' AND deadline<?", (now(),))


# ---------------- to'lovlar ----------------
def create_payment(user_id, kind, ref_id, amount, file_id, file_unique_id):
    """Yangi to'lov chekini yozadi. Shu chek avval ishlatilgan bo'lsa None qaytaradi."""
    with _lock:
        dup = one(
            "SELECT 1 FROM payments WHERE file_unique_id=? AND status!='rejected'",
            (file_unique_id,),
        )
        if dup:
            return None
        return run(
            "INSERT INTO payments(user_id,kind,ref_id,amount,file_id,file_unique_id,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (user_id, kind, ref_id, amount, file_id, file_unique_id, now()),
        )


def get_payment(payment_id: int):
    return one("SELECT * FROM payments WHERE id=?", (payment_id,))


def decide_payment(payment_id: int, status: str, admin_id: int) -> bool:
    """Faqat kutilayotgan to'lovni hal qiladi. Ikki admin bir vaqtda bossa, bittasi o'tadi."""
    with _lock:
        cur = conn().execute(
            "UPDATE payments SET status=?, decided_at=?, decided_by=? WHERE id=? AND status='pending'",
            (status, now(), admin_id, payment_id),
        )
        conn().commit()
        return cur.rowcount == 1


def pending_payments():
    return all_("SELECT * FROM payments WHERE status='pending' ORDER BY id")


def has_pending_payment(kind: str, ref_id: int) -> bool:
    return one(
        "SELECT 1 FROM payments WHERE kind=? AND ref_id=? AND status='pending'", (kind, ref_id)
    ) is not None


# ---------------- ustozlar ----------------
def create_teacher(user_id, full_name, org) -> int:
    return run(
        "INSERT INTO teachers(user_id,full_name,org,max_students,created_at) VALUES(?,?,?,?,?)",
        (user_id, full_name, org, config.TEACHER_MAX_STUDENTS, now()),
    )


def get_teacher(teacher_id: int):
    return one("SELECT * FROM teachers WHERE id=?", (teacher_id,))


def teacher_by_code(code: str):
    return one("SELECT * FROM teachers WHERE code=?", (code,))


def teachers_of(user_id: int):
    return all_("SELECT * FROM teachers WHERE user_id=? ORDER BY id DESC", (user_id,))


def activate_teacher(teacher_id: int) -> str:
    code = secrets.token_urlsafe(6).replace("-", "x").replace("_", "y")
    run(
        "UPDATE teachers SET status='active', code=?, activated_at=? WHERE id=?",
        (code, now(), teacher_id),
    )
    return code


def close_teacher(teacher_id: int) -> None:
    run("UPDATE teachers SET status='closed', closed_at=? WHERE id=?", (now(), teacher_id))


def teacher_students(teacher_id: int):
    return all_(
        "SELECT * FROM attempts WHERE teacher_id=? ORDER BY "
        "(score_pct IS NULL), score_pct DESC, id",
        (teacher_id,),
    )


def slots_taken(teacher_id: int) -> int:
    """Band joylar soni. Har bir o'quvchi (user_id) faqat bitta joy egallaydi."""
    r = one(
        "SELECT COUNT(DISTINCT user_id) AS n FROM attempts WHERE teacher_id=?", (teacher_id,)
    )
    return r["n"]


def student_in_teacher(teacher_id: int, user_id: int):
    return one(
        "SELECT * FROM attempts WHERE teacher_id=? AND user_id=? ORDER BY id DESC LIMIT 1",
        (teacher_id, user_id),
    )


def claim_slot(user_id, teacher_id, full_name, age):
    """Joy bo'sh bo'lsa o'quvchi urinishini yaratadi. Yo'q bo'lsa None.
    Tekshiruv va yozish bitta qulf ichida, shuning uchun 11-o'quvchi sig'maydi."""
    with _lock:
        t = get_teacher(teacher_id)
        if not t or t["status"] != "active":
            return None
        if slots_taken(teacher_id) >= t["max_students"]:
            return None
        return create_attempt(user_id, "student", teacher_id, full_name, age)


# ---------------- sertifikat so'rovlari ----------------
def create_cert(user_id, attempt_id, teacher_id, full_name):
    with _lock:
        if one("SELECT 1 FROM certs WHERE attempt_id=?", (attempt_id,)):
            return None
        return run(
            "INSERT INTO certs(user_id,attempt_id,teacher_id,full_name,created_at) VALUES(?,?,?,?,?)",
            (user_id, attempt_id, teacher_id, full_name, now()),
        )


def get_cert(cert_id: int):
    return one("SELECT * FROM certs WHERE id=?", (cert_id,))


def cert_for_attempt(attempt_id: int):
    return one("SELECT * FROM certs WHERE attempt_id=?", (attempt_id,))


def pending_certs():
    return all_("SELECT * FROM certs WHERE status='pending' ORDER BY id")


def mark_cert_sent(cert_id: int) -> None:
    run("UPDATE certs SET status='sent', sent_at=? WHERE id=?", (now(), cert_id))


# ---------------- statistika ----------------
def stats() -> dict:
    def n(sql, args=()):
        return one(sql, args)[0]

    total_users = n("SELECT COUNT(*) FROM users")
    in_progress = n("SELECT COUNT(*) FROM attempts WHERE status='in_progress'")
    finished = n("SELECT COUNT(*) FROM attempts WHERE status!='in_progress'")
    started_users = n("SELECT COUNT(DISTINCT user_id) FROM attempts")
    paid = n("SELECT COUNT(*) FROM payments WHERE status='approved'")
    revenue = n("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='approved'")
    return dict(
        total_users=total_users,
        started_users=started_users,
        in_progress=in_progress,
        finished=finished,
        pending_payments=n("SELECT COUNT(*) FROM payments WHERE status='pending'"),
        pending_certs=n("SELECT COUNT(*) FROM certs WHERE status='pending'"),
        paid=paid,
        revenue=revenue,
        teachers_active=n("SELECT COUNT(*) FROM teachers WHERE status='active'"),
        teachers_total=n("SELECT COUNT(*) FROM teachers WHERE status!='awaiting_payment'"),
    )
