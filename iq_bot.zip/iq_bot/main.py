"""IQ test boti: ishga tushirish fayli.

Ishga tushirish:
    pip install -r requirements.txt
    BOT_TOKEN=... python main.py
"""
import asyncio
import logging

from telegram.ext import (Application, CallbackQueryHandler, CommandHandler, MessageHandler,
                          PicklePersistence, filters)

import config
import core
import db
import h_admin
import h_teacher
import h_user
from texts import tr
from util import lang_of, log, menu_kb, safe_send


async def on_message(update, context):
    """Matn va rasmlarni foydalanuvchi holatiga qarab tegishli joyga yo'naltiradi."""
    msg = update.message
    if msg is None or update.effective_chat.type != "private":
        return
    u = update.effective_user
    db.upsert_user(u.id, u.username, u.first_name)

    if await h_admin.on_admin_message(update, context):
        return

    state = context.user_data.get("state")
    lang = lang_of(u.id)
    has_text = bool(msg.text)

    if state in ("name", "age", "t_name", "t_org") and not has_text:
        await safe_send(context.bot, u.id, tr(lang, "text_bad"))
    elif state == "name":
        await h_user.on_name(update, context)
    elif state == "age":
        await h_user.on_age(update, context)
    elif state == "t_name":
        await h_teacher.on_teacher_name(update, context)
    elif state == "t_org":
        await h_teacher.on_teacher_org(update, context)
    elif state == "receipt" or msg.photo:
        if not await h_user.on_receipt(update, context) and msg.photo:
            await safe_send(context.bot, u.id, tr(lang, "menu_title"), reply_markup=menu_kb(lang))
    else:
        if db.get_lang(u.id):
            await safe_send(context.bot, u.id, tr(lang, "menu_title"), reply_markup=menu_kb(lang))
        else:
            await h_user.proceed(update, context)


async def on_error(update, context):
    log.error("Xatolik: %s", context.error, exc_info=context.error)
    try:
        if update is not None and update.effective_chat is not None:
            await safe_send(context.bot, update.effective_chat.id,
                            tr(lang_of(update.effective_user.id), "error"))
    except Exception:
        pass


async def expiry_loop(app):
    """Vaqti tugagan testlarni avtomatik yakunlaydi."""
    while True:
        try:
            for a in db.overdue_attempts():
                await core.finalize(app.bot, a["id"], "expired")
        except Exception:
            log.exception("expiry_loop xatosi")
        await asyncio.sleep(30)


async def backup_loop(app):
    """Baza nusxasini adminlarga muntazam yuboradi."""
    while True:
        await asyncio.sleep(config.BACKUP_EVERY_HOURS * 3600)
        try:
            await h_admin.send_backup(app.bot, db.admin_ids())
        except Exception:
            log.exception("backup_loop xatosi")


async def post_init(app):
    app.bot_data["tasks"] = [asyncio.create_task(expiry_loop(app)),
                             asyncio.create_task(backup_loop(app))]
    log.info("Bot ishga tushdi: @%s", app.bot.username)


async def post_shutdown(app):
    for t in app.bot_data.get("tasks", []):
        t.cancel()


def main():
    logging.basicConfig(format="%(asctime)s %(levelname)s %(name)s: %(message)s", level=logging.INFO)
    if not config.BOT_TOKEN:
        raise SystemExit("BOT_TOKEN topilmadi. Tokenni muhit o'zgaruvchisi sifatida bering.")
    db.init()

    app = (
        Application.builder()
        .token(config.BOT_TOKEN)
        .persistence(PicklePersistence("data/state.pkl"))  # qayta ishga tushganda holatlar yo'qolmaydi
        .concurrent_updates(True)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    app.add_handler(CommandHandler("start", h_user.cmd_start, filters=filters.ChatType.PRIVATE))
    app.add_handler(CommandHandler("admin", h_admin.cmd_admin, filters=filters.ChatType.PRIVATE))

    cb = [
        (r"^lang:(uz|ru)$", h_user.cb_lang), (r"^chlang$", h_user.cb_change_lang),
        (r"^sub:check$", h_user.cb_sub_check), (r"^menu$", h_user.cb_menu), (r"^help$", h_user.cb_help),
        (r"^test:start$", h_user.cb_test_start), (r"^test:resume$", h_user.cb_test_resume),
        (r"^ans:\d+:\d+:\d+$", h_user.cb_answer),
        (r"^rcpt:\d+$", h_user.cb_rcpt), (r"^task:\d+:\d+$", h_user.cb_task), (r"^chk:\d+$", h_user.cb_check),
        (r"^res:list$", h_user.cb_results), (r"^res:\d+$", h_user.cb_result_open),
        (r"^cert:\d+$", h_user.cb_cert),
        (r"^tm$", h_teacher.cb_teacher_menu), (r"^tn$", h_teacher.cb_teacher_new),
        (r"^tl$", h_teacher.cb_teacher_list), (r"^tp:\d+$", h_teacher.cb_teacher_panel),
        (r"^ts:\d+$", h_teacher.cb_stop_confirm), (r"^tsy:\d+$", h_teacher.cb_stop_do),
        (r"^tc:\d+$", h_teacher.cb_teacher_cert), (r"^trc:\d+$", h_teacher.cb_teacher_receipt),
        (r"^a:", h_admin.cb_admin),
    ]
    for pattern, fn in cb:
        app.add_handler(CallbackQueryHandler(fn, pattern=pattern))

    app.add_handler(MessageHandler(filters.ChatType.PRIVATE & ~filters.COMMAND, on_message))
    app.add_error_handler(on_error)
    app.run_polling(allowed_updates=["message", "callback_query"], drop_pending_updates=False)


if __name__ == "__main__":
    main()
