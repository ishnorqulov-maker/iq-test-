"""Bot sozlamalari. Maxfiy narsalar (token) muhit o'zgaruvchisidan olinadi."""
import os
from datetime import timedelta, timezone

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

# Asosiy admin(lar) Telegram ID'si. Vergul bilan ajratib bir nechta yozish mumkin.
# Qo'shimcha adminlarni bot ichidagi admin paneldan qo'shish mumkin.
OWNER_IDS = [
    int(x)
    for x in os.environ.get("ADMIN_IDS", "6818724924").replace(" ", "").split(",")
    if x
]

DB_PATH = os.environ.get("DB_PATH", "data/iq_bot.sqlite3")

# Narxlar (so'mda)
PRICE_USER = 15_000
PRICE_TEACHER = 50_000

# Ustoz havolasiga qo'shila oladigan o'quvchilar soni
TEACHER_MAX_STUDENTS = 10

# Bitta urinish uchun vaqt (daqiqa) va ro'yxatdan o'tish uchun ushlab turish vaqti
TEST_MINUTES = 40
REGISTRATION_HOLD_MIN = 30

# To'lov kartalari (nomi, raqami) va karta egasi
CARDS = [
    ("Uzcard", "5614 6818 5135 6083"),
    ("Humo", "9860 6067 4378 4476"),
    ("Visa", "4413 5976 0021 9578"),
]
CARD_OWNER = "NORQULOV MANSUR"

# Baza nusxasini adminlarga avtomatik yuborish oralig'i (soat)
BACKUP_EVERY_HOURS = 12

# Ko'rsatiladigan vaqt mintaqasi: Toshkent (UTC+5)
TZ = timezone(timedelta(hours=5))
