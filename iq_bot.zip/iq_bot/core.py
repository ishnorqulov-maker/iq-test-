"""Test mexanizmi: savol berish, yakunlash, natija matni, ustozga xabar."""
import math
import random

import db
import scoring
from texts import PRAISES, TASKS, cards_text, money, tr
import config
from util import bar, esc, fmt_dt, kb, lang_of, safe_send

TOTAL = 30


def left_minutes(a) -> int:
    return max(1, math.ceil((a["deadline"] - db.now()) / 60))


def question_payload(a):
    """Joriy savol matni va tugmalari."""
    lang = lang_of(a["user_id"])
    _, text, shown, _ = scoring.build_view(a["seed"], a["pos"], lang)
    body = tr(lang, "q_header", n=a["pos"] + 1, total=TOTAL, left=left_minutes(a), text=esc(text))
    rows = [[(f"{chr(65 + i)}) {opt}", f"ans:{a['id']}:{a['pos']}:{i}")] for i, opt in enumerate(shown)]
    return body, kb(rows)


async def send_question(bot, a, query=None):
    """Savolni yuboradi; query berilsa, o'sha xabarni tahrirlaydi."""
    body, markup = question_payload(a)
    if query is not None:
        await query.edit_message_text(body, parse_mode="HTML", reply_markup=markup)
    else:
        await safe_send(bot, a["user_id"], body, reply_markup=markup)


def result_text(a, lang: str) -> str:
    pct, iq, cats = scoring.compute(a["answers"], a["age"])
    names = tr(lang, "cat_names")
    best, worst = scoring.strengths(cats)
    cat_lines = "\n".join(f"{names[c]}: {bar(p)} {p}%" for c, p in cats.items())
    return tr(
        lang, "result",
        name=esc(a["full_name"]), age=a["age"], rid=a["result_id"], date=fmt_dt(a["finished_at"]),
        iq=a["iq"], level=tr(lang, "level_names")[scoring.level_title(a["iq"])],
        correct=a["correct"], total=TOTAL, cats=cat_lines, best=names[best], worst=names[worst],
    )


async def show_result(bot, a):
    lang = lang_of(a["user_id"])
    await safe_send(
        bot, a["user_id"], result_text(a, lang),
        reply_markup=kb([[(tr(lang, "btn_cert"), f"cert:{a['id']}")],
                         [(tr(lang, "btn_menu"), "menu")]]),
    )


def pay_prompt_text(lang: str, kind_price: int, key: str = "pay_prompt") -> str:
    return tr(lang, key, price=money(kind_price), cards=cards_text(), owner=config.CARD_OWNER)


def pick_praise(lang: str) -> str:
    uz, ru = random.choice(PRAISES)
    return ru if lang == "ru" else uz


def task_text(lang: str, i: int) -> str:
    uz, ru = TASKS[i % len(TASKS)]
    return ru if lang == "ru" else uz


async def finalize(bot, attempt_id: int, status: str):
    """Testni yakunlaydi (status: finished | expired | stopped).
    Oddiy foydalanuvchiga to'lov so'raydi, o'quvchi bo'lsa ustozga xabar beradi."""
    a = db.get_attempt(attempt_id)
    if not a or a["status"] != "in_progress":
        return
    pct, iq, _ = scoring.compute(a["answers"], a["age"])
    if not db.finish_attempt(attempt_id, status, pct, iq):
        return  # boshqa jarayon allaqachon yakunlagan
    a = db.get_attempt(attempt_id)
    uid, lang = a["user_id"], lang_of(a["user_id"])

    if status == "expired":
        await safe_send(bot, uid, tr(lang, "time_up"))

    if a["kind"] == "user":
        await safe_send(
            bot, uid, pay_prompt_text(lang, config.PRICE_USER),
            reply_markup=kb([[(tr(lang, "btn_send_receipt"), f"rcpt:{attempt_id}")]]),
        )
        return

    # o'quvchi: ustozga xabar beriladi (ustoz to'xtatgan bo'lsa, o'quvchiga xabarni ustoz moduli yuboradi)
    if status != "stopped":
        await safe_send(bot, uid, tr(lang, "student_done"), reply_markup=kb([[(tr(lang, "btn_menu"), "menu")]]))
        t = db.get_teacher(a["teacher_id"])
        if t:
            tl = lang_of(t["user_id"])
            await safe_send(
                bot, t["user_id"],
                tr(tl, "teacher_notify_done", name=esc(a["full_name"]), iq=iq, correct=a["correct"], total=TOTAL),
            )
