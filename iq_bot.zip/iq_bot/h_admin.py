"""Admin paneli (faqat o'zbekcha): to'lovlar, sertifikatlar, kanallar, adminlar, statistika, xabar."""
import asyncio
import os
import sqlite3
import tempfile

from telegram.error import RetryAfter, TelegramError

import config
import core
import db
from texts import money, tr
from util import esc, fmt_dt, kb, lang_of, log, notify_admins, safe_send

ADMIN_STATES = ("adm_ch", "adm_addadmin", "adm_bc", "certid", "certimg")


def pct(a: int, b: int) -> str:
    return f"{round(100 * a / b)}%" if b else "0%"


def admin_menu_kb():
    return kb([
        [("📊 Statistika", "a:stats"), ("💳 To'lovlar", "a:pay")],
        [("🎓 Sertifikat tarqatish", "a:cert")],
        [("📢 Majburiy obuna", "a:ch"), ("👥 Adminlar", "a:adm")],
        [("📣 Xabar yuborish", "a:bc"), ("🗄 Baza nusxasi", "a:bk")],
    ])


async def cmd_admin(update, context):
    if not db.is_admin(update.effective_user.id):
        return
    context.user_data.pop("state", None)
    await safe_send(context.bot, update.effective_chat.id, "🛠 <b>Admin paneli</b>", reply_markup=admin_menu_kb())


async def show_admin_menu(q, context, text="🛠 <b>Admin paneli</b>"):
    try:
        await q.edit_message_text(text, parse_mode="HTML", reply_markup=admin_menu_kb())
    except TelegramError:
        await safe_send(context.bot, q.from_user.id, text, reply_markup=admin_menu_kb())


async def cb_admin(update, context):
    """'a:' bilan boshlanuvchi barcha admin tugmalari."""
    await admin_action(update, context, update.callback_query.data)


async def admin_action(update, context, data: str):
    q = update.callback_query
    uid = q.from_user.id
    if not db.is_admin(uid):
        await q.answer("Ruxsat yo'q", show_alert=True)
        return
    parts = data.split(":")
    act = parts[1]
    arg = parts[2] if len(parts) > 2 else None
    bot = context.bot
    chat = q.from_user.id
    back = [("⬅️ Admin paneli", "a:menu")]

    if act in ("payok", "payno"):
        await decide_payment(q, context, int(arg), act == "payok")
        return
    try:
        await q.answer()
    except TelegramError:
        pass  # tugma qayta chaqirilganda (o'chirishdan keyin) ikkinchi javob xato berishi mumkin

    if act == "menu":
        context.user_data.pop("state", None)
        await show_admin_menu(q, context)

    elif act == "stats":
        s = db.stats()
        attempts = s["in_progress"] + s["finished"]
        text = (
            "📊 <b>Statistika</b>\n\n"
            f"👥 Botga kirganlar: <b>{s['total_users']}</b>\n"
            f"🧪 Test boshlaganlar: <b>{s['started_users']}</b> ({pct(s['started_users'], s['total_users'])})\n\n"
            f"⏳ Hozir test yechayotganlar: <b>{s['in_progress']}</b> ({pct(s['in_progress'], attempts)})\n"
            f"✅ Testni yakunlaganlar: <b>{s['finished']}</b> ({pct(s['finished'], attempts)})\n"
            f"Jami urinishlar: {attempts}\n\n"
            f"💳 Tasdiqlangan to'lovlar: <b>{s['paid']}</b>\n"
            f"💰 Tushum: <b>{money(s['revenue'])} so'm</b>\n"
            f"🕓 Kutilayotgan to'lovlar: {s['pending_payments']}\n"
            f"🎓 Kutilayotgan sertifikatlar: {s['pending_certs']}\n"
            f"🏫 Ustoz havolalari: faol {s['teachers_active']}, jami {s['teachers_total']}"
        )
        await q.edit_message_text(text, parse_mode="HTML", reply_markup=kb([back]))

    elif act == "pay":
        pend = db.pending_payments()
        if not pend:
            await q.edit_message_text("💳 Kutilayotgan to'lovlar yo'q.", reply_markup=kb([back]))
            return
        await q.edit_message_text(f"💳 Kutilayotgan to'lovlar: {len(pend)} ta. Quyida yuboriladi.", reply_markup=kb([back]))
        for p in pend[:20]:
            who = describe_payment(p)
            try:
                await bot.send_photo(
                    chat, p["file_id"], parse_mode="HTML",
                    caption=f"💳 <b>To'lov #{p['id']}</b>\n{who}\nSumma: <b>{money(p['amount'])} so'm</b>\n"
                            f"Sana: {fmt_dt(p['created_at'])}\nID: <code>{p['user_id']}</code>",
                    reply_markup=kb([[("✅ Tasdiqlash", f"a:payok:{p['id']}"), ("❌ Rad etish", f"a:payno:{p['id']}")]]),
                )
            except TelegramError as e:
                log.warning("to'lov rasmini yuborib bo'lmadi: %s", e)

    elif act == "cert":
        pend = db.pending_certs()
        rows = [[(f"#{c['id']} · {c['full_name']}", f"a:certsend:{c['id']}")] for c in pend[:20]]
        rows.append([("🆔 Foydalanuvchi ID bo'yicha yuborish", "a:certid")])
        rows.append(back)
        head = f"🎓 <b>Sertifikat tarqatish</b>\nKutilayotgan so'rovlar: {len(pend)}" if pend else \
               "🎓 <b>Sertifikat tarqatish</b>\nKutilayotgan so'rov yo'q."
        await q.edit_message_text(head, parse_mode="HTML", reply_markup=kb(rows))

    elif act == "certsend":
        c = db.get_cert(int(arg))
        if not c or c["status"] != "pending":
            await q.answer("Bu so'rov allaqachon bajarilgan.", show_alert=True)
            return
        context.user_data["state"] = "certimg"
        context.user_data["certimg"] = {"cid": c["id"]}
        a = db.get_attempt(c["attempt_id"])
        await safe_send(
            bot, chat,
            f"🎓 <b>So'rov #{c['id']}</b>\nIsm: {esc(c['full_name'])}\nIQ: {a['iq'] if a else '-'}\n"
            f"Foydalanuvchi ID: <code>{c['user_id']}</code>\n\n"
            "Endi shu foydalanuvchiga yuboriladigan <b>sertifikat rasmini</b> (yoki faylini) yuboring.",
        )

    elif act == "certid":
        context.user_data["state"] = "certid"
        await safe_send(bot, chat, "🆔 Sertifikat yuboriladigan foydalanuvchining Telegram ID raqamini yozing.")

    elif act == "ch":
        rows = [[(f"🗑 {ch['title'] or ch['chat_id']}", f"a:chdel:{ch['id']}")] for ch in db.channels()]
        rows.append([("➕ Kanal qo'shish", "a:chadd")])
        rows.append(back)
        n = len(db.channels())
        await q.edit_message_text(
            f"📢 <b>Majburiy obuna kanallari</b>: {n} ta.\nO'chirish uchun kanal nomini bosing.\n\n"
            "Muhim: bot kanalda <b>admin</b> bo'lishi kerak, aks holda obuna tekshirilmaydi.",
            parse_mode="HTML", reply_markup=kb(rows))

    elif act == "chadd":
        context.user_data["state"] = "adm_ch"
        await safe_send(bot, chat, "📢 Kanalning @username'ini yozing (masalan <code>@mening_kanalim</code>), "
                                   "yoki kanaldan biror xabarni shu yerga forward qiling.\n"
                                   "Avval botni kanalga admin qilib qo'shing.")

    elif act == "chdel":
        db.del_channel(int(arg))
        await admin_action(update, context, "a:ch")

    elif act == "adm":
        rows = []
        for aid in db.admin_ids():
            owner = aid in config.OWNER_IDS
            rows.append([(f"{'👑' if owner else '🗑'} {aid}", "a:adm" if owner else f"a:admdel:{aid}")])
        rows.append([("➕ Admin qo'shish", "a:admadd")])
        rows.append(back)
        await q.edit_message_text("👥 <b>Adminlar</b>\n👑 asosiy admin (o'chirib bo'lmaydi). O'chirish uchun bosing.",
                                  parse_mode="HTML", reply_markup=kb(rows))

    elif act == "admadd":
        context.user_data["state"] = "adm_addadmin"
        await safe_send(bot, chat, "👥 Yangi adminning Telegram ID raqamini yozing.")

    elif act == "admdel":
        db.remove_admin(int(arg))
        await admin_action(update, context, "a:adm")

    elif act == "bc":
        context.user_data["state"] = "adm_bc"
        await safe_send(bot, chat, f"📣 Hamma foydalanuvchiga ({len(db.user_ids())} ta) yuboriladigan xabarni yuboring "
                                   "(matn, rasm yoki video bo'lishi mumkin).")

    elif act == "bcgo":
        bc = context.user_data.pop("bc", None)
        if not bc:
            return
        await q.edit_message_text("📣 Yuborilmoqda...")
        ok = fail = 0
        for uid_ in db.user_ids():
            for attempt in (1, 2):
                try:
                    await bot.copy_message(uid_, bc[0], bc[1])
                    ok += 1
                    break
                except RetryAfter as e:
                    await asyncio.sleep(e.retry_after + 1)
                except TelegramError:
                    fail += 1
                    break
            await asyncio.sleep(0.05)
        await safe_send(bot, chat, f"📣 Yuborildi: <b>{ok}</b>, yetib bormadi: {fail}", reply_markup=kb([back]))

    elif act == "bcno":
        context.user_data.pop("bc", None)
        await show_admin_menu(q, context)

    elif act == "bk":
        await send_backup(bot, [uid])


def describe_payment(p) -> str:
    if p["kind"] == "result":
        a = db.get_attempt(p["ref_id"])
        return f"Turi: IQ natijasi\nIsm: {esc(a['full_name']) if a else '-'}"
    t = db.get_teacher(p["ref_id"])
    return f"Turi: ustoz havolasi\nIsm: {esc(t['full_name']) if t else '-'} ({esc(t['org']) if t else '-'})"


# ---------------------------------------------------------------- to'lovni tasdiqlash/rad etish
async def decide_payment(q, context, pid: int, ok: bool):
    bot = context.bot
    p = db.get_payment(pid)
    if not p:
        await q.answer("To'lov topilmadi", show_alert=True)
        return
    if not db.decide_payment(pid, "approved" if ok else "rejected", q.from_user.id):
        await q.answer("Bu to'lov allaqachon hal qilingan.", show_alert=True)
        return
    await q.answer("Bajarildi")
    lang = lang_of(p["user_id"])

    if p["kind"] == "result":
        a = db.get_attempt(p["ref_id"])
        if ok:
            db.set_attempt_pay(a["id"], "approved")
            await safe_send(bot, p["user_id"], tr(lang, "pay_approved"))
            await core.show_result(bot, db.get_attempt(a["id"]))
        else:
            db.set_attempt_pay(a["id"], "rejected")
            await safe_send(bot, p["user_id"], tr(lang, "pay_rejected"),
                            reply_markup=kb([[(tr(lang, "btn_send_receipt"), f"rcpt:{a['id']}")]]))
    else:
        t = db.get_teacher(p["ref_id"])
        if ok:
            code = db.activate_teacher(t["id"])
            link = f"https://t.me/{bot.username}?start=t_{code}"
            await safe_send(bot, p["user_id"], tr(lang, "teacher_ready", link=link),
                            reply_markup=kb([[(tr(lang, "btn_teacher_mine"), "tl")]]))
        else:
            await safe_send(bot, p["user_id"], tr(lang, "pay_rejected"),
                            reply_markup=kb([[(tr(lang, "btn_send_receipt"), f"trc:{t['id']}")]]))

    mark = "✅ Tasdiqlandi" if ok else "❌ Rad etildi"
    try:
        old = q.message.caption_html or ""
        await q.edit_message_caption(f"{old}\n\n<b>{mark}</b> (admin {q.from_user.id}, {fmt_dt(db.now())})",
                                     parse_mode="HTML", reply_markup=None)
    except Exception:  # xabar eskirgan yoki o'zgartirib bo'lmasa, to'lov baribir hal qilingan
        pass


# ---------------------------------------------------------------- admin matnli/rasmli xabarlari
async def on_admin_message(update, context) -> bool:
    """Admin holatlariga tegishli xabar bo'lsa qayta ishlaydi va True qaytaradi."""
    uid = update.effective_user.id
    state = context.user_data.get("state")
    if state not in ADMIN_STATES or not db.is_admin(uid):
        return False
    msg, bot = update.message, context.bot

    if state == "adm_ch":
        ref = None
        fo = getattr(msg, "forward_origin", None)
        if fo is not None and getattr(fo, "chat", None) is not None:
            ref = fo.chat.id
        elif msg.text:
            ref = msg.text.strip()
            if ref.lstrip("-").isdigit():
                ref = int(ref)
        try:
            chat = await bot.get_chat(ref)
            me = await bot.get_chat_member(chat.id, bot.id)
            if me.status not in ("administrator", "creator"):
                await safe_send(bot, uid, "❌ Bot bu kanalda admin emas. Avval botni admin qiling va qayta urinib ko'ring.")
                return True
            if chat.username:
                link = f"https://t.me/{chat.username}"
            else:
                link = chat.invite_link or await bot.export_chat_invite_link(chat.id)
        except (TelegramError, TypeError) as e:
            await safe_send(bot, uid, f"❌ Kanal topilmadi yoki xatolik: {esc(e)}")
            return True
        db.add_channel(str(chat.id), chat.title, link)
        context.user_data.pop("state", None)
        await safe_send(bot, uid, f"✅ Kanal qo'shildi: <b>{esc(chat.title)}</b>", reply_markup=kb([[("⬅️ Admin paneli", "a:menu")]]))

    elif state == "adm_addadmin":
        txt = (msg.text or "").strip()
        if not txt.isdigit():
            await safe_send(bot, uid, "❌ Faqat raqamli Telegram ID yozing.")
            return True
        db.add_admin(int(txt))
        context.user_data.pop("state", None)
        await safe_send(bot, uid, f"✅ Admin qo'shildi: <code>{txt}</code>", reply_markup=kb([[("⬅️ Admin paneli", "a:menu")]]))

    elif state == "adm_bc":
        context.user_data["bc"] = (msg.chat_id, msg.message_id)
        context.user_data.pop("state", None)
        await safe_send(bot, uid, f"Yuqoridagi xabar <b>{len(db.user_ids())}</b> ta foydalanuvchiga yuboriladi. Tasdiqlaysizmi?",
                        reply_markup=kb([[("✅ Yuborish", "a:bcgo"), ("❌ Bekor", "a:bcno")]]))

    elif state == "certid":
        txt = (msg.text or "").strip()
        if not txt.isdigit():
            await safe_send(bot, uid, "❌ Faqat raqamli Telegram ID yozing.")
            return True
        context.user_data["certimg"] = {"uid": int(txt)}
        context.user_data["state"] = "certimg"
        await safe_send(bot, uid, f"Endi <code>{txt}</code> ga yuboriladigan sertifikat rasmini yuboring.")

    elif state == "certimg":
        target = context.user_data.get("certimg") or {}
        if not (msg.photo or msg.document):
            await safe_send(bot, uid, "❌ Iltimos, sertifikatni rasm yoki fayl ko'rinishida yuboring.")
            return True
        if "cid" in target:
            c = db.get_cert(target["cid"])
            if not c or c["status"] != "pending":
                context.user_data.pop("state", None)
                await safe_send(bot, uid, "Bu so'rov allaqachon bajarilgan.")
                return True
            to, lang = c["user_id"], lang_of(c["user_id"])
            key = "teacher_cert_sent" if c["teacher_id"] else "cert_caption"
            caption = tr(lang, key, name=esc(c["full_name"]))
        else:
            c, to = None, target["uid"]
            caption = "🎓 Sizning sertifikatingiz tayyor! 🎉"
        try:
            await bot.copy_message(to, msg.chat_id, msg.message_id, caption=caption, parse_mode="HTML")
        except TelegramError as e:
            await safe_send(bot, uid, f"❌ Yuborib bo'lmadi: {esc(e)}\nFoydalanuvchi botni to'xtatgan bo'lishi mumkin.")
            return True
        if c:
            db.mark_cert_sent(c["id"])
        context.user_data.pop("state", None)
        context.user_data.pop("certimg", None)
        await safe_send(bot, uid, f"✅ Sertifikat <code>{to}</code> ga yuborildi.",
                        reply_markup=kb([[("🎓 Yana sertifikat", "a:cert"), ("⬅️ Admin paneli", "a:menu")]]))
    return True


# ---------------------------------------------------------------- baza nusxasi
async def send_backup(bot, admin_ids):
    """SQLite bazaning xavfsiz nusxasini adminlarga fayl qilib yuboradi."""
    tmp = tempfile.NamedTemporaryFile(suffix=".sqlite3", delete=False)
    tmp.close()
    try:
        with db._lock:
            dst = sqlite3.connect(tmp.name)
            db.conn().backup(dst)
            dst.close()
        for aid in admin_ids:
            try:
                with open(tmp.name, "rb") as f:
                    await bot.send_document(aid, f, filename=f"iq_bot_{fmt_dt(db.now()).replace(':', '-').replace(' ', '_')}.sqlite3",
                                            caption="🗄 Baza nusxasi")
            except TelegramError as e:
                log.warning("backup yuborilmadi (%s): %s", aid, e)
    finally:
        os.unlink(tmp.name)
