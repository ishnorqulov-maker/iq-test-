"""30 ta savol: (matn, variantlar, to'g'ri javob indeksi, qiyinlik 1-3, toifa, izoh)."""

SERIES, LOGIC, VERBAL, SPACE, MATH = "series", "logic", "verbal", "space", "math"

CATEGORY_NAMES = {
    SERIES: "Raqamlar ketma-ketligi",
    LOGIC: "Mantiqiy fikrlash",
    VERBAL: "So'z va tushunchalar",
    SPACE: "Fazoviy tasavvur",
    MATH: "Matematik fikrlash",
}

# Har bir element: dict(q, o, a, w, c, e)
QUESTIONS = [
    # ---- Raqamlar ketma-ketligi (8) ----
    dict(q="Ketma-ketlikni davom ettiring:\n3, 6, 9, 12, ?",
         o=["14", "15", "16", "18"], a=1, w=1, c=SERIES,
         e="Har safar 3 qo'shiladi."),
    dict(q="Ketma-ketlikni davom ettiring:\n2, 6, 18, 54, ?",
         o=["108", "148", "162", "216"], a=2, w=1, c=SERIES,
         e="Har bir son 3 ga ko'paytiriladi: 54 x 3 = 162."),
    dict(q="Ketma-ketlikni davom ettiring:\n1, 4, 9, 16, 25, ?",
         o=["30", "34", "36", "49"], a=2, w=1, c=SERIES,
         e="Bular 1, 2, 3, 4, 5, 6 sonlarining kvadratlari: 6 x 6 = 36."),
    dict(q="Ketma-ketlikni davom ettiring:\n1, 2, 4, 7, 11, 16, ?",
         o=["21", "22", "23", "24"], a=1, w=2, c=SERIES,
         e="Farqlar 1, 2, 3, 4, 5, keyingisi 6: 16 + 6 = 22."),
    dict(q="Ketma-ketlikni davom ettiring:\n2, 3, 5, 7, 11, 13, ?",
         o=["15", "17", "19", "21"], a=1, w=2, c=SERIES,
         e="Bular tub sonlar. 13 dan keyingi tub son 17."),
    dict(q="Ketma-ketlikni davom ettiring:\n2, 5, 11, 23, ?",
         o=["44", "46", "47", "49"], a=2, w=2, c=SERIES,
         e="Har safar 2 ga ko'paytirib 1 qo'shiladi: 23 x 2 + 1 = 47."),
    dict(q="Ketma-ketlikni davom ettiring:\n100, 91, 83, 76, 70, ?",
         o=["64", "65", "66", "67"], a=1, w=3, c=SERIES,
         e="Ayirmalar 9, 8, 7, 6, keyingisi 5: 70 - 5 = 65."),
    dict(q="Ketma-ketlikni davom ettiring:\n3, 8, 6, 11, 9, 14, ?",
         o=["11", "12", "16", "17"], a=1, w=3, c=SERIES,
         e="Navbat bilan +5 va -2 qilinadi: 14 - 2 = 12."),

    # ---- Mantiqiy fikrlash (8) ----
    dict(q="Barcha o'qituvchilar bilimli. Aziza o'qituvchi.\nDemak:",
         o=["Aziza bilimli", "Aziza bilimli emas",
            "Barcha bilimlilar o'qituvchi", "Aniqlab bo'lmaydi"],
         a=0, w=1, c=LOGIC, e="Aziza o'qituvchilar guruhiga kiradi, ular esa bilimli."),
    dict(q="Ali Validan katta, Vali Samidan katta, Sami Karimdan katta.\nEng kichigi kim?",
         o=["Ali", "Vali", "Sami", "Karim"], a=3, w=1, c=LOGIC,
         e="Tartib: Ali > Vali > Sami > Karim."),
    dict(q="Qaysi biri ortiqcha?",
         o=["Olma", "Sabzi", "Nok", "Behi"], a=1, w=1, c=LOGIC,
         e="Boshqalari mevalar, sabzi esa sabzavot."),
    dict(q="Hamma A lar B. Hech bir B C emas.\nDemak:",
         o=["Ba'zi A lar C", "Hech bir A C emas", "Hamma C lar A", "Hamma B lar C"],
         a=1, w=2, c=LOGIC, e="A lar B ning ichida, B lar esa C bilan kesishmaydi."),
    dict(q="Bugun dushanba. 100 kundan keyin haftaning qaysi kuni bo'ladi?",
         o=["Seshanba", "Chorshanba", "Payshanba", "Juma"], a=1, w=2, c=LOGIC,
         e="100 = 14 x 7 + 2, ya'ni dushanbadan 2 kun keyin: chorshanba."),
    dict(q="5 ta mushuk 5 ta sichqonni 5 daqiqada tutadi.\n"
           "100 ta mushuk 100 ta sichqonni necha daqiqada tutadi?",
         o=["5", "20", "100", "500"], a=0, w=2, c=LOGIC,
         e="Har bir mushuk 5 daqiqada 1 ta sichqon tutadi."),
    dict(q="Ota o'g'ilidan 30 yosh katta. 5 yildan keyin ota o'g'ilidan 4 marta katta bo'ladi.\n"
           "O'g'il hozir necha yoshda?",
         o=["3", "5", "6", "10"], a=1, w=3, c=LOGIC,
         e="O'g'il 5, ota 35. 5 yildan keyin 10 va 40: 4 marta."),
    dict(q="Uch do'st gapirdi. A: «B yolg'onchi». B: «C yolg'onchi». "
           "C: «A ham, B ham yolg'onchi».\nFaqat bittasi rost gapirgan. Kim?",
         o=["A", "B", "C", "Aniqlab bo'lmaydi"], a=1, w=3, c=LOGIC,
         e="B rost bo'lsa, C va A yolg'on gapirgan, shart bajariladi. "
           "A yoki C rost bo'lsa, ziddiyat chiqadi."),

    # ---- So'z va tushunchalar (5) ----
    dict(q="Qaysi so'z «jasur» so'ziga ma'nodosh?",
         o=["Qo'rqoq", "Botir", "Dangasa", "Aqlli"], a=1, w=1, c=VERBAL,
         e="Jasur va botir bir xil ma'noni bildiradi."),
    dict(q="Qo'l : Barmoq = Daraxt : ?",
         o=["Ildiz", "Novda", "Tuproq", "Soya"], a=1, w=1, c=VERBAL,
         e="Barmoq qo'lning bir qismi, novda daraxtning bir qismi."),
    dict(q="Issiq : Sovuq = Kun : ?",
         o=["Quyosh", "Tun", "Yoz", "Oy"], a=1, w=1, c=VERBAL,
         e="Zid ma'noli juftlik: issiq-sovuq, kun-tun."),
    dict(q="Shifokor : Kasalxona = O'qituvchi : ?",
         o=["Maktab", "Kitob", "Doska", "Talaba"], a=0, w=2, c=VERBAL,
         e="Kasb egasi va uning ish joyi."),
    dict(q="Qalam : Yozmoq = Pichoq : ?",
         o=["Kesmoq", "O'tkir", "Oshxona", "Metall"], a=0, w=2, c=VERBAL,
         e="Asbob va uning vazifasi."),

    # ---- Fazoviy tasavvur (6) ----
    dict(q="Kubning nechta qirrasi bor?",
         o=["6", "8", "12", "16"], a=2, w=1, c=SPACE,
         e="Kubda 6 yoq, 8 uchi va 12 qirra bor."),
    dict(q="Ko'zguda soat 3:00 ko'rinyapti. Haqiqiy vaqt qancha?",
         o=["3:00", "6:00", "9:00", "12:00"], a=2, w=2, c=SPACE,
         e="Ko'zgu chap va o'ngni almashtiradi, 3:00 ning aksi 9:00."),
    dict(q="Siz shimolga qarab turibsiz. O'ngga 90 daraja, yana o'ngga 90 daraja, "
           "keyin chapga 90 daraja burildingiz. Qaysi tomonga qaraysiz?",
         o=["Shimol", "Sharq", "Janub", "G'arb"], a=1, w=2, c=SPACE,
         e="Shimol, sharq, janub, keyin chapga burilib sharq."),
    dict(q="3 x 3 katakli katta kvadratda har xil o'lchamdagi jami nechta kvadrat bor?",
         o=["9", "10", "14", "15"], a=2, w=3, c=SPACE,
         e="1x1: 9 ta, 2x2: 4 ta, 3x3: 1 ta. Jami 14."),
    dict(q="Tashqi tomoni bo'yalgan 3x3x3 kub 27 ta kichik kubchaga bo'lindi.\n"
           "Nechta kubchaning hech bir yog'i bo'yalmagan?",
         o=["0", "1", "6", "8"], a=1, w=3, c=SPACE,
         e="Faqat eng markazdagi bitta kubcha ichkarida qoladi."),
    dict(q="Soat 3:15 da soat va minut mili orasidagi burchak necha daraja?",
         o=["0", "7,5", "15", "30"], a=1, w=3, c=SPACE,
         e="Soat mili 97,5 darajada, minut mili 90 darajada: farq 7,5."),

    # ---- Matematik fikrlash (3) ----
    dict(q="Bir ishni 6 ishchi 10 kunda bitiradi. 12 ishchi necha kunda bitiradi?",
         o=["4", "5", "6", "20"], a=1, w=1, c=MATH,
         e="Ishchi 2 marta ko'p, vaqt 2 marta kam: 5 kun."),
    dict(q="Mahsulot narxi 20% oshirildi, keyin yangi narxdan 20% arzonlashtirildi.\n"
           "Boshlang'ich narxga nisbatan natija qanday?",
         o=["O'zgarmadi", "4% arzon", "4% qimmat", "2% arzon"], a=1, w=2, c=MATH,
         e="1,2 x 0,8 = 0,96, ya'ni 4% arzon."),
    dict(q="Ko'ldagi nilufar har kuni 2 barobar ko'payadi va 30 kunda ko'lni to'liq qoplaydi.\n"
           "Ko'lning yarmini necha kunda qoplagan?",
         o=["15", "25", "28", "29"], a=3, w=3, c=MATH,
         e="Oxirgi kuni 2 barobar ko'payib to'liq bo'ladi, demak 29-kuni yarmi."),
]

assert len(QUESTIONS) == 30
